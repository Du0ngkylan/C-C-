#ifndef FACE_H_
#define FACE_H_
#include <vector>
#include "Define.h"
using namespace std;

class Face {
public:
    bool m_IsBoundaryFace;
    int m_nFaceID;
    int m_nOwnerCell;
    int m_nNeighbourCell;
    vector<int> m_vPointID;
	Face();
	virtual ~Face();

    void operator=(Face face)
    {
    	this->m_IsBoundaryFace = face.m_IsBoundaryFace;
    	this->m_nFaceID = face.m_nFaceID;
    	this->m_nOwnerCell = face.m_nOwnerCell;
    	this->m_nNeighbourCell = face.m_nNeighbourCell;
    	this->m_vPointID = face.m_vPointID;
    }
};

#endif /* FACE_H_ */
