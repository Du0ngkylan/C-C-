/*
 * Boundary.cpp
 *
 *  Created on: Apr 3, 2018
 *      Author: DuongMX
 */

#include "Boundary.h"

Boundary::Boundary() {
	// TODO Auto-generated constructor stub
	this->m_nBoundaryID = NO_DEFINED;
	this->m_nFace = NO_DEFINED;
	this->m_nStartFace = NO_DEFINED;
	this->m_strType = STRING_EMPTY;
	this->m_strBoundaryName = STRING_EMPTY;
}

Boundary::Boundary(long nBoundaryID, long nFace, long nStartFace, string strType, string strBoundaryName){
	this->m_nBoundaryID = nBoundaryID;
	this->m_nFace = nFace;
	this->m_nStartFace = nStartFace;
	this->m_strType = strType;
	this->m_strBoundaryName = strBoundaryName;
}

Boundary::~Boundary() {
	// TODO Auto-generated destructor stub
}

