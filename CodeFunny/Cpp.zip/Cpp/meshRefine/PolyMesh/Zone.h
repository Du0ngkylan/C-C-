#ifndef ZONE_H_
#define ZONE_H_
#include <string>
#include <vector>
#include "Define.h"
using namespace std;

class Zone {
public:
	string m_strZoneName;
	vector<long> m_vCellID;
	Zone();
	Zone(string strZone, vector<long> vCellID);
	virtual ~Zone();
};

#endif /* ZONE_H_ */
