#ifndef POINT_H_
#define POINT_H_
#include "Define.h"

class Point {
public:
	long m_nPointID;
	double m_pX, m_pY, m_pZ;
	Point();
	Point(long nPointID, double pX, double pY, double pZ);
	virtual ~Point();

    void operator=(Point point)
    {
    	this->m_nPointID = point.m_nPointID;
    	this->m_pX = point.m_pX;
    	this->m_pY = point.m_pY;
    	this->m_pZ = point.m_pZ;
    }
};

#endif /* POINT_H_ */
