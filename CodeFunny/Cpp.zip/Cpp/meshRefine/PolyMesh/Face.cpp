#include "Face.h"

Face::Face() {
	// TODO Auto-generated constructor stub
    this->m_IsBoundaryFace = true;
    this->m_nFaceID = NO_DEFINED;
    this->m_nOwnerCell = NO_DEFINED;
    this->m_nNeighbourCell = NO_DEFINED;
    this->m_vPointID.clear();

}

Face::~Face() {
	// TODO Auto-generated destructor stub
}

