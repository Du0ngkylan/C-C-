#include "Point.h"

Point::Point() {
	// TODO Auto-generated constructor stub
	this->m_nPointID = NO_DEFINED;
	this->m_pX = NO_DEFINED;
	this->m_pY = NO_DEFINED;
	this->m_pZ = NO_DEFINED;

}

Point::Point(long nPointID, double pX, double pY, double pZ){
	this->m_nPointID = nPointID;
	this->m_pX = pX;
	this->m_pY = pY;
	this->m_pZ = pZ;
}

Point::~Point() {
	// TODO Auto-generated destructor stub
}

