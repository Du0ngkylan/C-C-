#include "Zone.h"

Zone::Zone() {
	// TODO Auto-generated constructor stub
	this->m_strZoneName = STRING_EMPTY;
	this->m_vCellID.clear();

}

Zone::Zone(string strZoneName, vector<long> vCellID){
	this->m_strZoneName = strZoneName;
	this->m_vCellID = vCellID;
}

Zone::~Zone() {
	// TODO Auto-generated destructor stub
}

