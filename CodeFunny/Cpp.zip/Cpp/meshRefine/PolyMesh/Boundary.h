#ifndef BOUNDARY_H_
#define BOUNDARY_H_
#include <string>
#include "Define.h"
using namespace std;

class Boundary {
public:
    long m_nBoundaryID,m_nFace,m_nStartFace;
    string m_strType,m_strBoundaryName;
	Boundary();
	Boundary(long nBoundaryID, long nFace, long nStartFace, string strType, string strBoundaryName);
	virtual ~Boundary();

    void operator=(Boundary boundary)
    {
    	this->m_nBoundaryID = boundary.m_nBoundaryID;
    	this->m_nStartFace = boundary.m_nStartFace;
    	this->m_nFace = boundary.m_nFace;
    	this->m_strType = boundary.m_strType;
    	this->m_strBoundaryName = boundary.m_strBoundaryName;
    }
};

#endif /* BOUNDARY_H_ */
