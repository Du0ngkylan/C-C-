#include <CApp.h>

CApp::CApp() {
	// TODO Auto-generated constructor stub

}

CApp::~CApp() {
	// TODO Auto-generated destructor stub
}

