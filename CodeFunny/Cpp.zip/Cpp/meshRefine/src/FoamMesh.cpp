#include <FoamMesh.h>
#include <iostream>

FoamMesh::FoamMesh() {
	// TODO Auto-generated constructor stub
	this->m_strPathFile = STRING_EMPTY;
	this->m_vBoundary.clear();
	this->m_vFace.clear();
	this->m_vNeighbour.clear();
	this->m_vOwner.clear();
	this->m_vPoint.clear();
	this->m_vZone.clear();

}

FoamMesh::FoamMesh(string strFilePath)
{
	this->m_strPathFile = strFilePath + "/polyMesh/";
	ParseMeshData(this->m_strPathFile);
}

void FoamMesh::ParseMeshData(string strFilePath)
{
	bool bResult = false;

	bResult = DataFileIO::ReadFileBoundary(strFilePath + "boundary", m_vBoundary);

	cout << "vBoundary = " << m_vBoundary.size() << endl;

	if(!bResult)
	{
		cout << "Read file boundary fail" << endl;
	}

	bResult = DataFileIO::ReadFilePoints(strFilePath + "points", m_vPoint);

	cout << "vPoint = " << m_vPoint.size() << endl;
	if(!bResult)
	{
		cout << "Read file points fail" << endl;
	}

//	bResult = DataFileIO::ReadFileFace(strFilePath + "faces", m_vFace);
//	if(!bResult)
//	{
//		cout << "Read file faces fail" << endl;
//	}
//
//	bResult = DataFileIO::ReadFileOwner_Neighbour(strFilePath + "owner", m_vOwner);
//	if(!bResult)
//	{
//		cout << "Read file owner fail" << endl;
//	}
//
//	bResult = DataFileIO::ReadFileOwner_Neighbour(strFilePath + "neighbour", m_vNeighbour);
//	if(!bResult)
//	{
//		cout << "Read file neighbour fail" << endl;
//	}
//
//	bResult = DataFileIO::ReadFileCellZones(strFilePath + "cellZones", m_vZone);
//	if(!bResult)
//	{
//		cout << "Read file cellZones fail" << endl;
//	}
}

FoamMesh::~FoamMesh() {
	// TODO Auto-generated destructor stub
}

