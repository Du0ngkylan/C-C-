//============================================================================
// Name        : meshRefine.cpp
// Author      : DuongMX
// Version     : 1.0
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "CApp.h"
#include "FoamMesh.h"
using namespace std;

int main(int argc, char *argv[])
{
//	if(argc != 5)
//	{
//		cout << "Usage: meshRefine -r regionName -p direction";
//		return 0;
//	}
	string strFilePath = "C:/Users/maixu_000/Desktop/ex1_OpenFOAM/ex1/constant/ab";
	FoamMesh mesh(strFilePath);

	cout << "XXXX" << endl;

	return 0;
}
