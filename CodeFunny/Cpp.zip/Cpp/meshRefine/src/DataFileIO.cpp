#include "DataFileIO.h"
#include <string>
#include <cstdlib>
using namespace std;

DataFileIO::DataFileIO() {
	// TODO Auto-generated constructor stub

}

DataFileIO::~DataFileIO() {
	// TODO Auto-generated destructor stub
}


void DataFileIO::ParseHeader(vector<string> vLines, map<string, string> &mFoamFile, int &nNumLine)
{
	int nLengh = vLines.size();
	string strLine = STRING_EMPTY;
	bool headerSection = false;

	for(nNumLine = 0; nNumLine < nLengh; nNumLine++)
	{
		strLine = vLines[nNumLine];
		if(strLine.empty())
		{
			continue;
		}

		if(strLine == "FoamFile")
		{
            headerSection = true;
            continue;
		}

		if(headerSection == true)
		{
            if(strLine == "{")
            {
            	continue;
            }
            else if(strLine == "}")
            {
            	headerSection = false;
            	break;
            }
            else
            {
            	mFoamFile[strLine] = "xyz";
            }
		}

	}
}



bool DataFileIO::ReadFileBoundary(string strFilePath, vector<Boundary> &vBoundary)
{
	ifstream pFile(strFilePath.c_str());

	if(!pFile)
	{
		cerr << "Cannot open the File" << strFilePath << endl;
		return false;
	}

	int nCountBoundary = 0;
	string strLine = STRING_EMPTY;
	bool bd1 = false;
	Boundary bd;

	while(pFile.peek() != EOF)
	{
		getline(pFile, strLine);
		Utils::StandString(strLine);
		cout << strLine << endl;

		if(Utils::IsValidNumber(strLine))
		{
			nCountBoundary = atoi(strLine.c_str());
			continue;
		}

		if(strLine == "(")
		{
			while(pFile.peek() != EOF)
			{
				getline(pFile, strLine);
				Utils::StandString(strLine);

				if(strLine.find(")") == static_cast<std::string::size_type>(0))
					break;

				if(bd1 == true)
				{
					if(strLine == "}")
					{
						vBoundary.push_back(bd);
						bd1 = false;
						continue;
					}
					else if(strLine.find("nFaces") == static_cast<std::string::size_type>(0))
					{
						cout << "nFace =>" << strLine << endl;
					}
					else if(strLine.find("startFace") == static_cast<std::string::size_type>(0))
					{
						cout << "startFace =>" << strLine << endl;
					}
				}

				if(bd1 == false)
				{
					if(strLine.find("{") == static_cast<std::string::size_type>(0))
					{
						bd1 = true;
						continue;
					}
					else
					{
						cout << "boundaryName = " <<strLine << endl;
					}
				}

			}
		}
	}

	pFile.close();

	if(nCountBoundary != (int)vBoundary.size())
		return false;

	return true;
}

bool DataFileIO::ReadFilePoints(string strFilePath, vector<Point> &vPoint)
{
	ifstream pFile(strFilePath.c_str());

	if(!pFile)
	{
		cerr << "Cannot open the File" << strFilePath << endl;
		return false;
	}

	int nCountPoint = 0;
	string strLine = STRING_EMPTY;
	vector<double> vTemp;
	vector<string> vHeader;

	Utils::ParseHeader(&pFile, vHeader);
	cout << "vHeader = " << vHeader.size() << endl;

	while(pFile.peek() != EOF)
	{
		getline(pFile, strLine);
		Utils::StandString(strLine);

		if(Utils::IsValidNumber(strLine))
		{
			nCountPoint = atoi(strLine.c_str());
			continue;
		}

		if(strLine == "(")
		{
			int nPointID = 0;
			while(pFile.peek() != EOF)
			{
				getline(pFile, strLine);
				Utils::StandString(strLine);

				if(strLine.find(")") == static_cast<std::string::size_type>(0))
					break;

				vTemp = Utils::ParsePointContent(strLine);
				if(vTemp.size() != 3)
				{
					pFile.close();
					return false;
				}

				Point point(++nPointID, vTemp[0], vTemp[1], vTemp[2]);
				vPoint.push_back(point);
			}
		}
	}

	pFile.close();

	if(nCountPoint != (int)vPoint.size())
		return false;
	return true;
}

bool DataFileIO::ReadFileFace(string strFilePath, vector<Face> &vFace)
{
	vector<string> vLines;
	bool bRes = Utils::ReadAllLine(strFilePath, vLines);

	if(!bRes)
		return false;

	string strLine = STRING_EMPTY;
	int nNumLine = 0;
	int nFace = 0;
	int nLengh = vLines.size();

	while(nNumLine < nLengh)
	{
		strLine = vLines[nNumLine];
		if(Utils::IsValidNumber(strLine))
		{
			nFace = atoi(strLine.c_str());
		}

		nNumLine++;
	}


	return true;
}

bool DataFileIO::ReadFileOwner_Neighbour(string strFilePath, vector<long> &vData)
{
	return true;
}

bool DataFileIO::ReadFileCellZones(string strFilePath, vector<Zone> &vZone)
{
	return true;
}

bool DataFileIO::WriteBoundary(string strFilePath, vector<Boundary> &vBoundary)
{
	return true;
}

bool DataFileIO::WritePoint(string strFilePath, vector<Point> &vPoint)
{
	return true;
}

bool DataFileIO::WriteFace(string strFilePath, vector<Boundary> &vBoundary)
{
	return true;
}

bool DataFileIO::WriteOwner_Neighbour(string strFilePath,vector<long> &vData, long nPoint, long nCell, long nFace, long nInternalFace)
{
	return true;
}

bool DataFileIO::WriteCellZones(string strFilePath, vector<Zone> &vZone)
{
	return true;
}
