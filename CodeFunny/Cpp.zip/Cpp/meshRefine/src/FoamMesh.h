#ifndef FOAMMESH_H_
#define FOAMMESH_H_
#include <string>
#include <vector>
#include "Define.h"
#include "Boundary.h"
#include "Point.h"
#include "Face.h"
#include "Zone.h"
#include "DataFileIO.h"
using namespace std;
class FoamMesh {
public:
	string m_strPathFile;
    vector<Boundary> m_vBoundary;
    vector<Point> m_vPoint;
    vector<Face> m_vFace;
    vector<Zone> m_vZone;
    vector<long> m_vOwner;
    vector<long> m_vNeighbour;
	FoamMesh();
	FoamMesh(string strFilePath);
	void ParseMeshData(string strFilePath);
	virtual ~FoamMesh();
};

#endif /* FOAMMESH_H_ */
