#ifndef DATAFILEIO_H_
#define DATAFILEIO_H_
#include <map>
#include "Define.h"
#include "Utils.h"
#include "Boundary.h"
#include "Point.h"
#include "Face.h"
#include "Zone.h"
using namespace std;

class DataFileIO {
public:
	DataFileIO();
	static void ParseHeader(vector<string> vLines, map<string, string> &mFoamFile, int &nNumLine);
	static bool ReadFileBoundary(string strFilePath, vector<Boundary> &vBoundary);
	static bool ReadFilePoints(string strFilePath, vector<Point> &vPoint);
	static bool ReadFileFace(string strFilePath, vector<Face> &vFace);
	static bool ReadFileOwner_Neighbour(string strFilePath, vector<long> &vData);
	static bool ReadFileCellZones(string strFilePath, vector<Zone> &vZone);

	bool WriteBoundary(string strFilePath, vector<Boundary> &vBoundary);
	bool WritePoint(string strFilePath, vector<Point> &vPoint);
	bool WriteFace(string strFilePath, vector<Boundary> &vBoundary);
	bool WriteOwner_Neighbour(string strFilePath,vector<long> &vData, long nPoint, long nCell, long nFace, long nInternalFace);
	bool WriteCellZones(string strFilePath, vector<Zone> &vZone);

	virtual ~DataFileIO();
};

#endif /* DATAFILEIO_H_ */
