#ifndef CAPP_H_
#define CAPP_H_

class CApp {
public:
	CApp();
	virtual ~CApp();
};

#endif /* CAPP_H_ */
