#include <Utils.h>

Utils::Utils() {
	// TODO Auto-generated constructor stub

}

Utils::~Utils() {
	// TODO Auto-generated destructor stub
}

void Utils::StandString(string &str)
{
	if (str.empty())
	{
		return;
	}

	str.erase(remove(str.begin(), str.end(), CHAR_DOWN_LINE), str.end()); //Remove '\r'
	size_t posBegin = str.find_first_not_of(STRING_STAND_SET);
	size_t posEnd = str.find_last_not_of(STRING_STAND_SET);
	if (posBegin != string::npos && posEnd != string::npos)
	{
		long nCount = posEnd-posBegin+1;
		if (nCount >= 1)
		{
			str = str.substr(posBegin, nCount);
		}
		else
		{
			str = STRING_EMPTY;
		}
	}
}

bool Utils::IsValidNumber(string &str)
{
	if(str.empty())
		return false;

	string strLegalChars = STRING_NUMBER_SET;
	for (string::iterator it = str.begin() ; it != str.end() ; ++it)
	{
		//The string must have each character in set of "0123456789 +-."
		//Otherwise, this string is invalid Gravity
		if(strLegalChars.find(*it) == string::npos)
		{
			return false;
		}
	}

	return true;
}

string Utils::GetCurrentDir()
{


    return STRING_EMPTY;
}

bool Utils::CreateParentDir(const char* pszPath)
{
	return true;
}

void Utils::TrimHeadTab(string &str)
{
	size_t nPos = NO_DEFINED;
	string sToken = STRING_EMPTY;
	string strTmp = STRING_EMPTY;
	long nLength = NO_DEFINED;

	if (str.empty())
	{
		return;
	}

	//Replace all '\r' to '\n' first
	replace(str.begin(),str.end(),CHAR_DOWN_LINE,CHAR_DOWN_LINE1);

	while ((nPos = str.find_first_of(CHAR_DOWN_LINE1)) != string::npos)
	{
		nLength = str.length();
		sToken = str.substr(0, nPos+1);
		sToken.erase(0, sToken.find_first_not_of(SET_SPACE_TAB));
		sToken.erase(sToken.find_last_not_of(SET_SPACE_TAB)+1);

		strTmp += sToken;
		str = str.substr(nPos+1, nLength);
	}

	str = strTmp;
}

void Utils::RemoveDir(string &strDir)
{

}


bool Utils::ReadAllLine(string strFilePath, vector<string> &vLines)
{
	std::ifstream inFile(strFilePath.c_str());

	if(!inFile)
	{
		std::cerr << "Cannot open the File : " << strFilePath << std::endl;
		return false;
	}

	string str = STRING_EMPTY;
	while (getline(inFile, str))
	{
		StandString(str);
		vLines.push_back(str);
	}

	inFile.close();
	return true;
}

void Utils::ParseHeader(ifstream* pFile,vector<string>& vHeader)
{
	string strLine = STRING_EMPTY;
	while(pFile->peek() != EOF)
	{
		getline(*pFile, strLine);
		vHeader.push_back(strLine);
		Utils::StandString(strLine);
		if(strLine.find("}") == static_cast<std::string::size_type>(0))
			break;
	}
}

vector<double> Utils::ParsePointContent(string &str)
{
	vector<double> vResult;
	int p1 = str.find_first_of("(");
	int p2 = str.find_first_of(")");

	string strTemp = str.substr(p1 + 1, p2 - p1 - 1);
	double tmp;
	istringstream iss(strTemp);

	while(iss >> tmp)
		vResult.push_back(tmp);

	return vResult;
}

bool Utils::StartWith(string &strMain, string &strMatch)
{
	return strMain.substr(0,strMatch.length()) == strMatch ;
}

bool Utils::IsNumber(const char *szStr)
{
	if(NULL == szStr || *szStr == '\0')
		return false;

	int countDot = 0;
	int countPlus = 0;
	int countMinus = 0;

	while(*szStr)
	{
		char c = *szStr;

		switch(c)
		{
		case '.':
			if(++countDot > 1)
				return false;
			break;
		case '-':
			if(++countMinus > 1)
				return false;
			break;
		case '+':
			if(++countPlus > 1)
				return false;
			break;
		default:
			if(c < '0' || c > '9')
				return false;
		}
	}

	return true;
}
