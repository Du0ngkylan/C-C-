#ifndef DEFINE_H_
#define DEFINE_H_

//***************************************************************************//
#define COMMON_BRACE_OPEN                       	  "{"
#define COMMON_BRACE_CLOSE                      	  "}"
#define COMMON_TAB                              	  '\t'
#define COMMON_SEMICOLON                        	  ';'
#define COMMON_SPACE                            	  ' '
#define FOLDER_OUTPUT_2                               "OpenFOAM-2.0.1"
#define FOLDER_OUTPUT_3                               "OpenFOAM-3.0.1"
#define VERSION_DEFAULT                               2
#define VERSION_SETTING                               3
//***************************************************************************//
#define EQUAL_KEY                                     "="
#define COMMA_KEY                                     ","
#define CHAR_COMMA_KEY								  ','
#define CHAR_MINUS									  '-'
#define CHAR_DOT									  '.'
#define CHAR_PLUS									  '+'
#define CHAR_E										  'e'
#define DOWN_LINE                                     "\r"
#define CHAR_DOWN_LINE                                '\r'
#define CHAR_DOWN_LINE1								  '\n'
#define STRING_OPEN_BRACKET							  "("
#define STRING_CLOSE_BRACKET						  ")"
#define NO_DEFINED									  -1
#define STRING_EMPTY								  ""
#define CHAR_EMPTY                              	  '\0'
#define STRING_SLASH								  "/"
#define STRING_DOT									  "."
#define ARG_DETECT									  "-d"		//String to determine Detect mode
#define ARG_SETTING									  "-t"		//String to determine Setting mode
#define EMPTY_ARRAY									  {0}
#define STRING_SPACE								  " "
#define STRING_DOUBLE_SLASH							  "//"
#define STRING_STAND_SET							  " \n\t\r"
#define STRING_INVALID_CHAR_SET						  "!@#$%^&(\\/){}[]|?><"
#define STRING_VALID_CHAR_SET						  "0123456789e., -+\t"
#define STRING_GRAVITY_SET							  "(0123456789 +-.)"
#define STRING_ERROR								  "ERROR"
#define NO_SELECTED_BOUNDARY_NAME					  "noSelected"
#define STRING_NUMBER_SET							  "0123456789 +-.eE,"
#define STRING_QUOTATION							  "\""
#define SET_SPACE_TAB								  " \t"
#define	MIN_POINT_PER_FACE							  3
#define	MAX_POINT_PER_FACE							  4

//***************************************************************************//
#define WIDTH_VAL0									   9
#define WIDTH_VAL1									   17
#define WIDTH_VAL2									   21
#define WIDTH_VAL3									   25
#define WIDTH_VAL4									   30
#define WIDTH_VAL5									   35

enum EBOUNDARY_TYPE
{
    CONNECT,
    CONSTVALUE,
    ZEROGRADIENT,
    INLET,
    OUTLET,
	RADIATION//[2017.04.03 - FPT)DuongMX- Add]
};
//[2017.06.20-FPT)DuongMX - #21918 - Modify]: Start
enum ECELL_TYPE
{
	OTHER = 0,
    C3D4 = 4,
    C3D6 = 6,
    C3D8 = 8,
	C3D46 = C3D4 + C3D6,
	C3D48 = C3D4 + C3D8,
	C3D68 = C3D6 + C3D8,
	C3D468 = C3D4 + C3D6 + C3D8
};
//[2017.06.20-FPT)DuongMX - #21918 - Modify]: End
enum EMATERIAL_TYPE
{
	UNKNOW,
    SOLID,
    FLUID,
    CONDUCTOR
};

enum ECONVERT_MODE
{
    ERR,
    NORMAL,
    DETECT,
    SETTING
};

enum EFACE_TYPE
{
	NONE,
	S1,
	S2,
	S3,
	S4,
	S5,
	S6
};

enum EFOAM_FILE
{
	O_QH,
	O_T,
	O_IDEFAULT,
	O_KAPPAT,
	O_PRGH,
	O_U,
	O_EPSILON,
	O_K,
	O_V,
	O_E,
	O_I,
	O_QC,
	O_DI,
	C_REGION,
	C_SOLID,
	C_BOUNDARY,
	C_CELLZONE,
	C_FACE,
	C_POINT,
	C_OWNER,
	C_NEIGHBOUR,
	C_G,
	C_RADIATIONPRO,
	C_RAS,
	C_TRANS,
	S_CONTROL,
	S_DECOM1,
	S_FVSCHEME1,
	S_FVSOL1,
	S_DECOM2,
	S_FVSCHEME2,
	S_FVSOL2,
	//[2017.04.03 - FPT)DuongMX- Add] : Start
	O_ST,
	O_NUT,
	O_P,
	O_CP,
	O_ALPHAT,
	O_KAPPA,
	O_S,
	O_RHO,
	C_TURBULEN,
	C_THERM,
	S_OPTION
	//[2017.04.03 - FPT)DuongMX- Add] : End
};

enum ESET_VALUE
{
	E_CP=1,
	E_KAPPA,
	E_RHO,
	E_MOLWEIGHT,
	E_MU,
	E_PR,
	E_EMISSIVITY,
	E_SIGMA
};



#endif /* DEFINE_H_ */
