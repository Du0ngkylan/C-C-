#ifndef UTILS_H_
#define UTILS_H_
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <libgen.h>
#include <fcntl.h>
#include "stdlib.h"
#include "stdio.h"
#include "Define.h"
using namespace std;

class Utils {
public:
	Utils();
	static void StandString(string &str);
	static bool IsValidNumber(string &str);
	static string GetCurrentDir();
	static bool CreateParentDir(const char* pszPath);
	static void TrimHeadTab(string &str);
	static void RemoveDir(string &strDir);
	static bool ReadAllLine(string strFilePath, vector<string> &vLines);
	static bool StartWith(string &strMain, string &strMatch);
	static bool is_integer(string &str);
	static bool IsNumber(const char *szStr);
	static void ParseHeader(ifstream* pFile, vector<string> &vHeader);
	static vector<double> ParsePointContent(string &str);
	virtual ~Utils();
};

#endif /* UTILS_H_ */
