#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

struct nhanvien{
	char msnv[50];
	char tennv[100];
	int songaycong;
	int luong;
	char chucvu[50];
	int traluong;
};

// Nhap thong tin nhan vien //
void nhapthongtin(struct nhanvien a[], int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("================================\n");
		printf("Nhap ten nhan vien thu %d",i+1);
		printf("\n");
		printf("Nhap ten nhan vien : ");
		gets(a[i].tennv);
		fflush(stdin);
		printf("Nhap msnv :");
		gets(a[i].msnv);
		fflush(stdin);
		printf("Nhap vao so ngay cong :");
		scanf("%d",&a[i].songaycong);
		fflush(stdin);
		printf("Nhap vao tien luong :");
		scanf("%d",&a[i].luong);
		fflush(stdin);
		printf("Nhap chuc vu :");
		gets(a[i].chucvu);
		fflush(stdin);
		}
}
// Xuat thong tin nhan vien //
void xuatthongtin(struct nhanvien a[], int n)
{
	printf("\t\t\t \n---------------THONG TIN QUAN LI NHAN VIEN-----------------");
	printf("\n %-30s %-20s %-10s %-20s %-20s %-20s \n", "Ten nhan vien", "MSNV", "So ngay cong", "Tien luong", "Chuc vu\n");
	int i;
	for(i=0;i<n;i++){
		printf("%-30s %-20s %-10d %-20d %-20s \n", a[i].tennv, a[i].msnv, a[i].songaycong, a[i].luong, a[i].chucvu );
	}
}

// Tien thuong //
int tienthuong(struct nhanvien a[], int n )
{
	int i,d=0;
	for(i=0;i<n;i++){
		if(a[i].songaycong > 24){
			d = d + 50;
		}
	}

	return d;
}
// Tien phu cap chuc vu //
int tienphucap(struct nhanvien a[], int n)
{
	int s=0;
	int i,j;

	for(i=0;i<n;i++)
        {

		if(strcmp(a[i].chucvu,"Giam Doc") == 0)
        {
			s= s + 100;
		}
		if(strcmp(a[i].chucvu,"Pho Giam Doc") == 0)
            {
			s= s + 80;
		}
		if(strcmp(a[i].chucvu,"Truong phong") == 0)
		{
			s= s + 40;
		}
		if(strcmp(a[i].chucvu," Pho phong") == 0)
		{
			s= s + 20;
        }
    }

	return s;
}
// Chuong trinh chay //
int main(){
	int n;
	int ff,nn;
	printf(" Nhap vao so nhan vien :");
	scanf("%d",&n);
	fflush(stdin);
	struct nhanvien nv[1000];
	nhapthongtin(nv,n);
	xuatthongtin(nv,n);
	nn=tienthuong(nv,n);
	printf(" Tien thuong la :%d ", nn);
    ff=tienphucap(nv, n);
	printf(" Tien phu cap la : %d", ff);
	getch();
	return 0;
}
