#include <iostream>

using namespace std;

int main()
{
//    cout << "Hello world!" << endl;
//    int n;
//    char abc[6];
//    cout << "Nhap n = ";
//    cin.width(5);
//    cin>>abc;
//    cout << "So Vua Nhap La: " << abc << endl;
//
//    int x = 445;
//    cout.width(5);
//    cout.fill('*');
//    cout << x;
//    cout <<endl;


    return 0;
}
