#include <iostream>

using namespace std;

class ConNguoi{
public:
    virtual void show(){
        cout << "Con Nguoi!!!" << endl;
    }
};

class NhanVien: public ConNguoi{
public:
    void show(){
        cout << "Nhan Vien!!!" << endl;
    }

    void showNhanVien(){
        cout << "XXXXXXXXXXXX" << endl;
    }
};

class HocSinh: public ConNguoi{
public:
    void show(){
        cout << "Hoc Sinh!!!" << endl;
    }
};

int main()
{
    ConNguoi *cn = new NhanVien; //Bí mật nằm ở virtual
    cn->show();
    ((NhanVien*)cn)->showNhanVien();


    return 0;
}
