/*
 * Vector.cpp
 *
 *  Created on: Aug 12, 2017
 *      Author: DuongMX
 */
#include <iostream>
#include <vector>
using namespace std;

int main()
{
	vector<int> v(20);
	for(int i = 0; i < 20; i++)
	{
		v[i] = i+1;
	}
	v.resize(25);
	for(int i = 20; i < 25; i++)
	{
		v[i] = i*2;
	}

	for (size_t i = 0; i < v.size(); ++i)
	{
		cout<< v[i]<<endl;
	}
	return 0;
}





