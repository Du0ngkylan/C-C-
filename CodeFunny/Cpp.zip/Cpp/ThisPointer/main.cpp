#include <iostream>

using namespace std;


void InputArray(int elements[], int limit)
{
    for (int i = 0; i < limit; i++)
    {
        cout <<"elements["<<i<<"]= ";
        cin >> elements[i];
    }
}

void OutputArray(int elements[], int limit)
{
    for(int i = 0; i < limit; i++)
    {
        cout <<"\t" <<elements[i];
    }
}

void BubbleSort(int elements[], int limit)
{
    for(int i = 0; i < limit; i++)
    {
        bool bSwap = true;
        for(int j = 0; j < limit - 1 - i; j++)
        {
            if(elements[j] > elements[j + 1])
            {
                bSwap = false;
                swap(elements[j], elements[j+1]);
            }
        }
        if(bSwap)
        {
            break;
        }
    }
}

void BubbleSort1(int elements[], int limit)
{
    int k = limit -2,nN;
    do
    {
        nN = 0;
        for(int i = 0; i < k; i++)
        {
            if(elements[i] > elements[i+1])
            {
                swap(elements[i], elements[i+1]);
                nN = i;
            }
        }
        k = nN;
    }while(k != 0);
}

int main()
{
    cout << "Hello world!" << endl;

//    float a = 10.0;
//    int *p = nullptr;
//    p = (int*)&a;
//    cout << "&a = " << &a << endl;
//    cout << "*p = "<< *p << endl;
//    cout <<"&p = " << &p << endl;
//    cout << "p = " << p << endl;
//    cout << "sizeof(a) = " << sizeof(a) <<endl;
//    cout << "sizeof(p) = " << sizeof(p) <<endl;


    int elements[100], limit;

    cout << "Input limit = ";
    cin >> limit;

    InputArray(elements, limit);
    cout << "Array: ";
    OutputArray(elements, limit);

    // sort
    BubbleSort1(elements, limit);
    cout << "\nArray sort: ";
    OutputArray(elements, limit);


    return 0;
}
