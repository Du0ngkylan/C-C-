#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
using namespace std;

int PTMax(int a[], int n)
{
    int nMax = a[0];
    for(int i = 1; i < n; i++)
    {
        if(a[i] >= nMax)
        {
            nMax = a[i];
        }
    }
    return nMax;
}


int main()
{
    int a[100];
    int n = 6;
    srand(time(NULL));
    for(int i = 0; i < n; i++)
    {
        a[i] = rand()%20 + 1;
    }

    cout<<"Mang Sau Khi Nhap La: ";
    for(int i = 0; i < n; i++)
    {
        cout << a[i] << "   ";
    }

    cout << "\nPT Max = " << PTMax(a,n);


    sort(a, a+n);
    cout << "\nMang sau khi sap xep: ";
    for(int i = 0; i < n; i++)
    {
        cout << a[i] << "   ";
    }
    return 0;
}
