#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int *NhapMang(int *a, int *n)
{
    printf("Nhap n: ");
    scanf("%d", n);

    a = (int *)malloc(sizeof(int *)*(*n));
    int i;
    for(i = 0; i < *n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", a + i);
    }
    return a;
}

void InMang(int *a, int n)
{
    int i;
    for(i = 0; i < n; i++)
    {
        printf("%5d", *(a + i));
    }
    puts("");
}

int main()
{
    int *a;
    int n;
    int ViTriThem, PhanTuThem;
    int PhanTuXoa;

    a = NhapMang(a, &n);
    InMang(a, n);

	// 0 <= ViTriThem <= n
	do
	{
		printf("\nNhap vao vi tri can them (%d --> %d): ", 0, n);
		scanf("%d", &ViTriThem);

		if (ViTriThem < 0 || ViTriThem > n)
		{
			printf("\nVi tri khong hop le!");
		}
	} while (ViTriThem < 0 || ViTriThem > n);

	printf("\nNhap vao phan tu can them: ");
	scanf("%d", &PhanTuThem);




    memmove( a + ViTriThem , a + (ViTriThem - 1) , (n - ViTriThem + 1)*sizeof(int));
    *(a + (ViTriThem - 1)) = PhanTuThem ;
    n++;
    printf("Mang Sau Khi Them: \n");
    InMang(a, n);

    printf("Nhap Gia Tri Can Xoa: ");
    scanf("%d", &PhanTuXoa);

//    for (i = 0; i < n; i++)
//    {
//        if(*(a + i) == PhanTuXoa)
//        {
//            memmove( a + i , a + i + 1 , (n - 1)*sizeof(int));
//            n--;
//            i--;
//        }
//    }
    int i = 0;
    while( i < n)
    {
        if(*(a + i) == PhanTuXoa)
        {
            memmove( a + i , a + i + 1 , (n - 1)*sizeof(int));
            n--;
        }
        else
        {
            i++;
        }
    }

    printf("Mang Sau Khi Xoa: \n");
    InMang(a,n);

    return 0;
}
