#ifndef SONGUYENTO_H_
#define SONGUYENTO_H_

int isPrimeNumber(int n);

struct Node *addNode(struct Node *list, int n);

struct Node *swapList(struct Node *list);

void printList(struct Node *list);

#endif /* SONGUYENTO_H_ */
