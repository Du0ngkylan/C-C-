#include <stdio.h>
#include <stdlib.h>
#include "SoNguyenTo.h"

int main()
{
    printf("Hello world!\n");

    struct Node *list = NULL;
	int i, n;
	printf("\nNhap n= ");
	scanf("%d", &n);

	for(i=0; i<n; i++)
	{
		if (isPrimeNumber(i))
		{
			list = addNode(list, i);
		}
	}
	printf("\nDanh sach so nguyen to:\n");
	printList(list);
	struct Node *q;
	q = swapList(list);
	printf("\nDanh sach da doi cho la:\n");
	printList(q);
    return 0;
}
