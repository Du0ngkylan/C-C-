#include <iostream>
#include<vector>

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    vector<int> vec;

    for(int i = 0; i < 10; i++)
    {
        vec.push_back(i);
    }

    for(vector<int>::iterator it = vec.begin(); it != vec.end(); ++it)
    {
        cout << " " << *it;
    }


    return 0;
}
