﻿#include<stdio.h>
#include<conio.h>


// 1. khai báo các cấu trúc dữ liệu danh sách đơn các số nguyên

struct Node{

	int Data;
	struct Node *pNext;
};
typedef struct Node NODE;

struct List{
	NODE *pHead;
	NODE *pTail;
};
typedef struct List LIST;

// 2. khởi tạo danh sách liên kết đơn

void Init(LIST &l){

	l.pHead = l.pTail = NULL;
}


// 3. Tạo Node trong danh sách
// x chính là dữ liệu đưa vào data
NODE *GetNode(int x){

	NODE *p = new NODE;

	if (p == NULL){
		return NULL;
	}
	p->Data = x;// lưu x vào data
	p->pNext = NULL; // khơi tạo mới liên kết. pnext không trỏ vào đâu hết

	return p;
}

// 4. Thêm node (thêm vào đầu hoặc cuối )



// thêm node p vào đầu danh sách
void AddHead(LIST &l, NODE *p){

	if (l.pHead == NULL){// danh sách bị rỗng
		l.pHead = l.pTail = p;
	}
	else{

		p->pNext = l.pHead;// p tạo liên kết để kết nối vào danh sách
		l.pHead = p;// p chính thức đứng đầu danh sách
	}
}

// thêm node p vào cuối danh sách
void AddTail(LIST &l, NODE *p){
	
	if (l.pHead == NULL){
		l.pHead = l.pTail = p;
	}
	else{

		l.pTail->pNext = p;// l.Tail tạo liên kết với p
		l.pTail = p;
	}
}

// 5. Nhập dữ liệu cho danh sách

void InPut(LIST &l){

	int n;
	printf_s("Nhap n = ");
	scanf_s("%d", &n);

	Init(l);
	for (int i = 1; i <= n; i++){

		// mỗi lần vòng lặp chạy ta nhập 1 node
		int x;
		printf_s("\nNhap vao data : ");
		scanf_s("%d", &x);

		NODE *p = GetNode(x);// đưa data vào node p, tạo ra node p
		AddTail(l, p);// thêm node p vào cuối danh sách
	}
}

void OutPut(LIST l){
	printf_s("\n");
	for (NODE *p = l.pHead; p != NULL; p = p->pNext){

		printf_s("%4d", p->Data);
	}

}

// Giải phóng danh sách

void GiaiPhong(LIST l){

	NODE *p;// khai báo node p
	while (l.pHead !=NULL)
	{
		p = l.pHead;// cho p trỏ tới head
		l.pHead = l.pHead->pNext;//Head trốn sang thằng bên cạnh
		delete p;// giải phóng p (cũng chính là giải phóng head ban đầu )
	}
}

int TimMax(LIST l){

	int Max = l.pHead->Data;

	for (NODE *p = l.pHead->pNext; p != NULL; p = p->pNext){
		if (p->Data > Max){
			Max = p->Data;
		}
	}

	return Max;
}


void HoanVi(int &a, int &b){
	int temp = a;
	a = b;
	b = temp;
}


void Sort(LIST &l){
	/*
	 for(int i =0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(a[i] > a[j])
				HoanVi(a[i],a[j]);
		}
	}
	*/

	for (NODE *p = l.pHead; p != l.pTail; p = p->pNext){
		for (NODE *q = p->pNext; q != NULL; q = q->pNext){

			if (p->Data > q->Data){
				HoanVi(p->Data, q->Data);
			}
		}
	}

}


// Thêm một node p vào sau node q

void ThemSau(LIST &l, NODE *p, NODE *q){

	for (NODE *k = l.pHead; k != NULL; k = k->pNext){
		
		if (k -> Data == q -> Data){// tìm thấy q

			NODE *g = k->pNext;
			k -> pNext = p;
			p -> pNext = g;
			return;// kết thúc
		}
	}
}

int main(){

	LIST l;
	InPut(l);
	OutPut(l);

	int MAX = TimMax(l);
	printf_s("\nPhan Tu Lon Nhat Danh Sach La: %d", MAX);

	Sort(l);
	printf_s("\nDanh Sach Sau Khi Sap Xep La: ");
	OutPut(l);



	int p, q;
	printf_s("\nNhap q = ");
	scanf_s("%d", &q);

	NODE *Q = GetNode(q);

	printf_s("\nNhap p = ");
	scanf_s("%d", &p);

	NODE *P = GetNode(p);

	ThemSau(l, P, Q);
	printf_s("\nSau Khi Them: ");
	OutPut(l);

	_getch();
	return 0;
}

