#include<iostream>
#include<cmath>
using namespace std;


int main(){

	unsigned long n,i;
	float S, x;

	cout << "\nNhap n= ";
	cin >> n;
	cout<<"\nNhap x= ";
	cin >> x;

	S = 0;
	for (i = 0; i <= n; i++)
		S =S+ float(pow(float(x), float(2 * i + 1)));
	

	cout << "S(n) = " << S << endl;

	system("pause");
	return 0;
}