﻿/*
Nhập vào 1 số nguyên dương n ,đếm xem có bao nhiêu chữ số. tìm xem chữ số lớn nhất, chữ số bé nhất
vd: 1234--> có 4 chữ số
chữ số lớn nhất là: 4
chữ số bé nhất là: 1
*/

#include<stdio.h>
#include<conio.h>
#include<math.h>


int main(){
	int n;
	do{
		printf_s("\nNhap vao so nguyen duong n : ");
		scanf_s("%d", &n);
		if (n <= 0){
			printf_s("\nBan nhap khong hop le,xin kiem tra lai!");
		}

	} while (n <= 0);

	//int dem = 0;
	int temp = n;// lưu tạm biến n

	/*while (temp != 0){
		temp = temp / 10;
		dem++;
		}*/

	int dem = log10((double)n)+1;

	printf_s("\nSo %d co %d chu so", n, dem);

	/*
	vd: 1234
	1234 % 10 = 4 (1)
	1234/10=123 // loại bỏ chữ số cuối

	123 % 10 = 3 (2)
	123 / 10 = 12

	12 % 10 = 2 (3)
	12 / 10 = 1 
	
	1 % 10 = 1 (4)
	1 / 10 = 0 --> dừng
	
	*/

	int max, min;
	max = min = temp % 10;// đặt max=min= chữ số cuối
	temp /= 10;// loại bỏ chữ số cuối

	while (temp != 0){

		int chuso = temp % 10;// lấy chữ số cuối
		temp /= 10;

		if (chuso > max){
			max = chuso;
		}
		if (chuso < min){
			min = chuso;
		}
	}

	printf_s("\nChu So Lon Nhat: %d", max);
	printf_s("\nChu So Nho Nhat: %d", min);
	_getch();
	return 0;
}