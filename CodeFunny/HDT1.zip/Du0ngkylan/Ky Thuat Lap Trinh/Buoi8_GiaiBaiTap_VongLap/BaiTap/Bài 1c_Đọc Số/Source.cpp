﻿/*
Thuật toán:
vd: 1234 ta đảo ngược số rồi đọc từ phải qua trái
*/

#include<stdio.h>
#include<conio.h>
#include<math.h>


int main(){
	int n;
	do{
		printf_s("\nNhap vao so nguyen duong (n>0) n = ");
		scanf_s("%d", &n);
		if (n <= 0){
			printf_s("\nSo ban nhap khong hop le, xin nhap lai: ");
		}

	} while (n<=0);

	int temp = n;
	int sochuso = log10((double)n);// đếm số chữ số của số n
	int sodaonguoc = 0;
	while (temp != 0){

		int chuso = temp % 10;// lấy ra chữ số cuối
		temp /= 10;// bỏ đi chữ số cuối
		sodaonguoc += chuso*pow(10.0, sochuso--);
	}

	printf_s("\nSo Dao Nguoc cua so %d la : %d", n, sodaonguoc);

	_getch();
	return 0;

}


