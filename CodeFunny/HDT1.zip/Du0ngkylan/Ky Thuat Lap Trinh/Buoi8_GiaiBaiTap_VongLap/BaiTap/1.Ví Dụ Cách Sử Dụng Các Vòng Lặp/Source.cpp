﻿/*
Vòng lặp cơ bản có 4 điều sau:
+ khởi đầu
+ điều kiện lặp
+ hành động
+ bước lặp

chú ý:
- vòng lặp sẽ không chạy nếu khởi đầu không thỏa mãn điều kiện lặp
- vòng lặp chạy vô tận

Có 4 loại vòng lặp:
1. For(khởi tạo; điều kiện lặp; bước lặp){
	hành động;
}

2. khởi tạo;
	while(điều kiện lặp){
		hành động;
		bước lặp;
	
	}

3. khởi tạo;
do{

 hành động;
 bước lặp;
}while(điều kiện lặp);

4. label:
	// hành động gì đó

	goto label;

*/

// Nhập vào 1 số chẵn, nếu là số lẻ bắt nhập lại



#include<stdio.h>
#include<conio.h>


int main(){

	/*int n;
	do{
		printf_s("\nNhap vao so chan: ");
		scanf_s("%d", &n);
		if (n % 2 != 0){
			printf_s("\nBan Nhap khong hop le!,xin nhap lai.");
		}
	} while (n%2!=0);*/

	int n;
	duongkylan:
	printf_s("\nNhap vao so chan: ");
	scanf_s("%d", &n);

	if (n % 2 != 0){
		printf_s("\nBan Nhap khong hop le!,xin nhap lai.");
		goto duongkylan;
	}

	printf_s("\nSo ban vua nhap la: %d", n);
	

	_getch();
	return 0;
}