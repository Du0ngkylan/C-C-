﻿/*
Nhập vào số nguyên dương tính:
a. S=1+2+3+...+n
b. S= 1^2+2^2+...n^2
c. S= 1 + 1/2+...+1/n
d. S= 1! + 2! + ...+ n!


*/


#include<stdio.h>
#include<conio.h>



int main(){
	int n;
	do{
		printf_s("\nNhap vao so nguyen duong (n>1): ");
		scanf_s("%d", &n);
		if (n < 1){
			printf_s("\nBan nhap khong hop le,xin nhap lai!");
		}

	} while (n < 1);


	/*int Sa = 0;
	for (int i = 1; i <= n; i++){
		Sa += i;
	}

	printf_s("\nTong Sa= %d", Sa);
*/

	int Sa = 0;
	int i = 1;
	while (i<=n)
	{
		//Sa += i;
		//i++;
		Sa += i++;
	}
	printf_s("\nTong Sa= %d", Sa);


// ý b
	int Sb = 0;
	for (int i = 1; i <= n; i++){
		Sb += i*i;
	}
	printf_s("\nTong Sb= %d", Sb);

// ý c

	float Sc = 0;
	for (int i = 1; i <= n; i++){
		Sc += 1.0 / i;
	}
	printf_s("\nTong Sc= %f", Sc);

// ý d
//S=1!+2!+..+n!
//--> 1 + 1*2 = 1*2*3+...
	
	int Sd = 0;
	/*for (int i = 1; i <= n; i++){
		int Tich = 1;
		for (int j = 1; j <= i; j++){
			Tich *= j;
		}
		Sd += Tich;
	}*/
	int Tich = 1;
	for (int i = 1; i <= n; i++){
		Tich *= i;
		Sd += Tich;
	}
	printf_s("\nTong Sd= %d", Sd);


	_getch();
	return 0;
}