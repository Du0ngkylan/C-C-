﻿/*Bài 1d: Hoám Vị 2 số nguyên*/



#include<stdio.h>
#include<conio.h>

void Nhap(int &n){
	printf_s("\nNhap So Nguyen: ");
	scanf_s("%d", &n);
}

// Dùng biến tạm
void HoanVi(int &a, int &b){
	int temp = a;
	a = b;
	b = temp;
}

//không dùng biến tạm

void HoanVi1(int &a, int &b){

	a = a+b;// gán đại
	b = a - b;//b=a
	a = a - b;//a=b
}

void SapXep(int &a, int &b, int &c, int &d){
	if (a > b){
		HoanVi(a, b);
	}
	if (a > c){
		HoanVi(a, c);
	}
	if (a > d){
		HoanVi(a, d);
	}
	if (b > c){
		HoanVi(b, c);
	}
	if (b > d){
		HoanVi(b, d);
	}
	if (c > d){
		HoanVi(c, d);
	}
}
int main(){
	int a, b,c,d;
	Nhap(a);
	Nhap(b);
	Nhap(c);
	Nhap(d);

	printf_s("\nDay So Ban Vua Nhap la: %d-->%d--->%d--->%d", a, b,c,d);

	SapXep(a, b, c, d);
	printf_s("\nSau khi Sap Xep: %d-->%d-->%d-->%d", a, b,c,d);

	_getch();
	return 0;
}