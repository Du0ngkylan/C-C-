
#include<stdio.h>
#include<conio.h>
#include<math.h>


void DaoSo(int &n){
	int tong=0;
	while (n!=0)
	{
		int sochuso = log10((double)n);
		tong += (n % 10) * pow(10.0, sochuso--);
		n /= 10;
	}
	n = tong;
	
}

void DocChuSo(int chuso){

	if (chuso == 1){
		printf_s(" Mot ");
	}
	else if (chuso == 2){
		printf_s(" Hai ");
	}
	else if (chuso == 3){
		printf_s(" Ba ");
	}
	else if (chuso == 4){
		printf_s(" Bon ");
	}
	else if (chuso == 5){
		printf_s(" Nam ");
	}
	else if (chuso == 6){
		printf_s(" Sau ");
	}
	else if (chuso == 7){
		printf_s(" Bay ");
	}
	else if (chuso == 8){
		printf_s(" Tam ");
	}
	else if (chuso == 9){
		printf_s(" Chin ");
	}
}

void DocPhuAm(int sochusoconlai){
	if (sochusoconlai == 1){
		printf_s(" Muoi");
	}
	else if (sochusoconlai == 2){
		printf_s(" Tram ");
	}
	else if (sochusoconlai == 3){
		printf_s(" Nghin ");
	}
	else if (sochusoconlai == 4){
		printf_s(" Muoi ");
	}
}

void DocSo(int n){

	DaoSo(n);

	while (n != 0){
		DocChuSo(n % 10);
		n /= 10;
		DocPhuAm(log10((double)n)+1);
	}
}

int main(){

	int n = 72136;

	DocSo(n);
	//DaoSo(n);
	//printf_s("\nn= %d", n);


	_getch();
	return 0;
}