﻿/*
Bài 2: Viết Hàm Nhập vào 1 số nguyên dương
a. trả về số đảo của số đó
b. có phải số đối xứng(trả về true, flase)
c. có phải là số chính phương
d. có phải số nguyên tố
e. Tổng các số lẻ
f. Tổng các chữ số nguyên tố
g. Tổng các số chính phương

*/


#include<stdio.h>
#include<conio.h>
#include<math.h>


void NhapDuLieu(int &n){
	do{
		printf_s("\nNhap Vao So Nguyen Duong: ");
		scanf_s("%d", &n);
		if (n <= 0){
			printf("\nBan Nhap chua dung!");
		}
	} while (n<=0);

}
//2a
void daoso(int n)
{
	if (n != 0)
	{
		printf("%d", n % 10);
		daoso(n / 10);
	}
}



//2c

int Kiemtrasochinhphuong(int a){

	double kq = sqrt(double(a));
	if (kq == (int)kq){
		return 1;
	}
	return 0;
}
//2d
int Kiemtranguyento(int n) {
	if (n<2) return 0;
	else {
		for (int i = 2; i <= sqrt(double(n)); i++)
		if (n%i == 0)
			return 0;
		return 1;
	}
}

//2e. tổng các số lẻ
int TongCacSoLe(int a){
	int tong = 0;
	while (a!=0)
	{
		int chuso = a % 10;
		a /= 10;// bỏ đi chữ số cuối
		if (chuso % 2 != 0){
			tong += chuso;
		}
	}
	return tong;
}
int main(){

	int n;
	NhapDuLieu(n);

	/*printf_s("\nSo Dao Nguoc la: ");
	daoso(n);

	if (Kiemtrasochinhphuong(n)){
		printf_s("\n%d la so chinh phuong", n);
	}
	else{
		printf_s("\n%d khong phai so chinh phuong", n);
	}*/
	
	int tongle = TongCacSoLe(n);
	printf_s("\nTong cac chu so le la: %d", tongle);





	_getch();
	return 0;
}