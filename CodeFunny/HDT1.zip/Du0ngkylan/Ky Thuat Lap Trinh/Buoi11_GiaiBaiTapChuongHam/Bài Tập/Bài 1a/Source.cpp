﻿/*
Bài 1a:
Viết hàm Đổi 1 kí tự hoa sang ký tự thường
A=>mã ASCII 65
a=>mã ASCII 97
*/

#include<stdio.h>
#include<conio.h>

// Hàm tham chiếu
void Nhap(char &x){
	printf("\nNhap Ky Tu: ");
	scanf_s("%c", &x);
}

char BienDoi_1(char x){

	if (x >= 'A' && x <= 'Z'){
		x += 32;
	}
	return x;
}

void BienDoi_2(char &x){

	if (x >= 'A' && x <= 'Z'){
		x += 32;
	}
}


int main(){
	char x;
	Nhap(x);

	//char c=BienDoi_1(x);
	//printf("\nKy Tu Sau Khi Bien Doi la: %c ", c);
	BienDoi_2(x);
	printf("\nKy Tu Sau Khi Bien Doi la: %c ", x);



	_getch();
	return 0;
}