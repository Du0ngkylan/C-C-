﻿/*
Bài 1b: Viết thủ tục giải phương trình bậc nhất ax+b=0


*/


#include<stdio.h>
#include<conio.h>
#include<math.h>

void NhapDuLieu(double &n){
	printf("\nNhap so Thuc : ");
	scanf("%lf", &n);
}

void GiaiPTBac1(double a, double b){

	if (a == 0){
		if (b == 0){
			printf("\nPhuong trinh vo so nghiem");
		}
		else{
			printf("\nPhuong trinh vo nghiem");
		}
	}
	else{

		double x = -b / a;
		printf("\nPhuong trinh co nghiem la: %lf",x);
	}
}

void GiaiPTBac2(double a, double b, double c){
	if (a == 0){
		GiaiPTBac1(b, c);
	}
	else{

		double denta = b*b - 4 * a*c;
		if (denta < 0){
			printf("\nPhuong Trinh Vo Nghiem");
		}
		else if (denta == 0){
			double x = -b / (2 * a);
			printf("\nPhuong Trinh co nghiem kep x1=x2= %lf" ,x);
		}
		else{
			double x1 = (-b - sqrt(denta)) / (2 * a);
			double x2 = (-b + sqrt(denta)) / (2 * a);

			printf("\nPT co 2 Nghiem: \nx1=%lf \nx2=%lf ", x1, x2);
		}

	}
}

int main(){

	double a, b,c;
	NhapDuLieu(a);
	NhapDuLieu(b);
	NhapDuLieu(c);
	GiaiPTBac2(a, b, c);


	_getch();
	return 0;
}