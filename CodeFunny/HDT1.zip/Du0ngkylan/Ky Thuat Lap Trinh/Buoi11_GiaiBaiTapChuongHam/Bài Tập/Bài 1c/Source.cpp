﻿
/*
Bài 1c: Tìm số nhỏ nhất trong 4 số a,b,c,d

Gán min= 1 số bất kỳ. lần lượt lấy các số còn lại so sánh với min.
rồi cập nhật lại min
*/


#include<stdio.h>
#include<conio.h>

void NhapDuLieu(int &n){
	printf_s("\nNhap vao: ");
	scanf_s("%d", &n);

}

//int TimMin(int a, int b, int c, int d){
//	int min = a;
//	if (b < min){
//		min = b;
//	}
//	if (c < min){
//		min = c;
//	}
//	if (d < min){
//		min = d;
//	}
//	return min;
//}

int TimMin(int a, int b){
	/*int min;
	if (a < b){
		min = a;
	}
	else{
		min = b;
	}
	return min;*/

	// toán tử 3 ngôi
	return a < b ? a : b;
}
int main(){
	int a, b, c, d;
	NhapDuLieu(a);
	NhapDuLieu(b);
	NhapDuLieu(c);
	NhapDuLieu(d);
	int min = TimMin(a, b);
	min = TimMin(min, c);
	min = TimMin(min, d);
	
	printf_s("\nMin= %d", min);


	_getch();
	return 0;
}

