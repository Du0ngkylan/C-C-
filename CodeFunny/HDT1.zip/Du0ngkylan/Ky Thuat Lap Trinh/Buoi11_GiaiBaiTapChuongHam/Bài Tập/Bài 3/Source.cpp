﻿/*
Bài 3: viết hàm nhập vào một số nguyên dương và thực hiện
a. S = 1+2+3+...+n
b. S = 1^2 + 2^2 + 3^2 + ...+n^2
c. S = 1 + 1/2 + 1/3 + ...+1/n
d. S = 1*2*3...*n
e. S = 1!+ 2!+ 3!+...+n!

*/


#include<stdio.h>
#include<conio.h>
#include<math.h>

void Nhap(int &n){
	printf_s("\nNhap vao So Nguyen: ");
	scanf_s("%d", &n);
}

void XuLy(int n,int &Sa,int &Sb,double &Sc,int &Sd,int &Se){
	Sa = 0;
	Sb = 0;
	Sc = 0;
	Sd = 1;
	Se = 0;

	for (int i = 1; i <= n; i++){
		Sa += i;
		Sb += i*i;
		Sc += 1 / i;
		Sd *= i;
		Se += Sd;
	}

}

int main(){
	int n;
	int Sa = 0;
	int Sb = 0;
	double Sc = 0.0;
	int Sd = 1;
	int Se = 0;
	Nhap(n);
	XuLy(n, Sa, Sb, Sc, Sd, Se);
	printf_s("\nTong lan luot la: \nSa= %d \nSb= %d \nSc= %lf \nSd= %d \nSe= %d", Sa, Sb,Sc,Sd,Se);



	_getch();
	return 0;
}




