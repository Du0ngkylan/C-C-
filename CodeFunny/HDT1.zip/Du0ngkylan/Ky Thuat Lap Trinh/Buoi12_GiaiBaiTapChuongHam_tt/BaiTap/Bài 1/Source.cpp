﻿/*
Bài 1: Viết chương trình trò chơi oẳn tù tì giữa người và máy theo thể lệ người luôn đi trước.

Luật chơi như sau: Người nhập vào ký tự tương ứng:
'B' hay 'b' => Búa
'O' hay 'o' => Bao
'K' hay 'k' => kéo

Sau đó Máy sẽ random ra ký tự bất kỳ (có thể là búa hoặc bao hoặc kéo).
Sau đó tính kết quả chung cuộc (người thắng hay máy thắng).

Gợi ý: Tham khảo cách Random số nguyên trong 1 đoạn nào đó,
ta có thể quy ước vd: số 1 => búa, 2 => bao, 3 => kéo.
Rồi tính thắng thua giữa người & máy theo nguyên tắc như ngoài đời:

- Búa thắng kéo nhưng thua bao
- Bao thắng búa nhưng thua kéo
- Kéo thắng bao nhưng thua búa.
*/



#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>




int main(){
	int i;
	printf("1.Dam\n");
	printf("2.La\n");
	printf("3.Keo\n");
	printf("chon muc thich ung:");
	scanf_s("%d", &i);

	printf_s("\nLua chon cua ban la: ");
	switch (i)
	{
	case 1:printf_s("\nDam");
		break;
	case 2:printf_s("\nLa");
		break;
	case 3:printf_s("\nKeo");
		break;
	}
	

	int m;
	srand(time_t(0));
	m = 1 + rand() % 3;
	printf_s("\nLua chon cua may la: ");
	switch (m)
	{
	case 1:printf_s("\nDam");
		break;
	case 2:printf_s("\nLa");
		break;
	case 3:printf_s("\nKeo");
		break;
	}
	
	

	_getch();
	return 0;
}