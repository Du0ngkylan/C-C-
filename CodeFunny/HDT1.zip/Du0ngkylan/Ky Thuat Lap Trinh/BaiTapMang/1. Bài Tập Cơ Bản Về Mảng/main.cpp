﻿#include<iostream>
#define MAX 100
using namespace std;


void NhapMang(int a[], int n){
	for (int i = 0; i < n; i++){
		cout << "a[" << i << "] = ";
		cin >> a[i];
	}
}

void XuatMang(int a[], int n){
	for (int i = 0; i < n; i++){
		cout << "\t"<<a[i];
	}
	cout << endl;
}

bool TimKiem(int a[], int n, int x){
	for (int i = 0; i < n; i++){
		if (a[i] == x){
			return 1;
		}		
	}
	return 0;
}

// kiểm tra xem mảng có toàn số dương không?
bool KiemTraSoDuong(int a[], int n){
	for (int i = 0; i < n; i++){
		if (a[i] < 0)
			return 0;
	}
	return 1;
}

// Tách Mảng

void TachMang(int a[], int n, int Temp[], int &nTemp){

	nTemp = 0;
	for (int i = 0; i < n; i++){
		if (a[i] %2 == 0){

			Temp[nTemp++] = a[i];
		}
	}
}

// Gộp Mảng

void GopMang(int a[], int &n,int Temp[],int nTemp){
	n += nTemp;
	for (int i = n - nTemp; i < n; i++){
		a[i] = Temp[i - (n - nTemp)];
	}
}

// Tìm Giá Trị Nhỏ Nhất/ Lớn Nhất Trong Mảng

int TimMin(int a[], int n){
	int Min = a[0];
	for (int i = 0; i < n; i++){
		if (a[i] < Min)
			Min = a[i];
	}
	return Min;
}

// Sắp Xếp

void Swap(int &a, int &b){
	int Temp =a;
	a = b;
	b = Temp;
}

void SapXep(int a[], int n){

	for (int i = 0; i < n - 1; i++){
		for (int j = i + 1; j < n; j++){
			if ( a[i] > a[j] ){
				Swap( a[i] , a[j] );
			}
		}
	}
}

// Thêm Một Phần Tử Vào Mảng

void ThemPhanTu(int a[], int &n,int VitriThem,int PhanTuThem){

	for (int i = n; i >= VitriThem + 1; i--){
		a[i] = a[i - 1];
	}
	n++; // Tăng số lượng phần tử lên
	a[VitriThem] = PhanTuThem;
}

int main(){

	int a[MAX],n;
	cout << "\nNhap So Phan Tu Mang: ";
	cin >> n;
	//int *a = new int[n];

	NhapMang(a, n);
	XuatMang(a, n);

	/*int x;
	cout << "\nNhap Vao Phan Tu Can Tim Kiem: ";
	cin >> x;

	if (TimKiem(a, n, x) == 1){
		cout << " co phan tu " << x << "  trong mang";
	}
	else{
		cout << "khong co phan tu " << x << "  trong mang";
	}*/

	/*if (KiemTraSoDuong(a, n) == 1){
		cout << "\nMang Toan So Duong! ";
	}
	else{
		cout << "\nMang Khong Phai Toan So Duong!"<<endl;
	}*/

	/*int Temp[MAX],nTemp;
	

	TachMang(a, n, Temp, nTemp);
	cout << "\nMang Temp La: ";
	XuatMang(Temp, nTemp);

	GopMang(a, n, Temp, nTemp);
	cout << "\nMang a Ban Dau La: ";
	XuatMang(a, n);
	*/


	/*int min = TimMin(a, n);
	cout << "\n Phan Tu Nho Nhat Mang La: "<< min<<endl;

	SapXep(a, n);
	cout << "\nMang Sau Khi Sap Xep La: ";
	XuatMang(a, n);*/

	int VitriThem, PhanTuThem;

	cout << "\nNhap Vi Tri Them : ";
	cin >> VitriThem;
	cout << "\nNhap Phan Tu Them : ";
	cin >> PhanTuThem;

	ThemPhanTu(a, n, VitriThem, PhanTuThem);
	cout << "\nMang Sau Khi Them: ";
	XuatMang(a, n);


	//delete[] a;

	system("pause");
}