﻿#include<stdio.h>
#include<conio.h>

//void DocDuLieu(int &a, int &b, FILE* &FileIn){
//
//	FileIn = fopen("Input.txt", "r");
//	fscanf_s(FileIn, "%d", &a);
//	fscanf_s(FileIn, "%d", &b);
//}



int main(){

	int a, b;

	FILE *FileIn;// khai báo tập tin FileIn

	FileIn = fopen("Input.txt", "r");// mở tập tin để đọc

	/*
	printf là xuất dữ liệu ra màn hình ( ghi ra màn hình)
	fprintf la xuất dữ liệu ra file ( ghi ra file )

	scanf là đọc dữ liệu từ bàn phím vào chương trình
	fscanf là đọc dữ liệu từ file vào chương trình	
	*/
	fscanf_s(FileIn, "%d", &a);
	fscanf_s(FileIn, "%d", &b);

	fclose(FileIn);// đóng file lại

    //printf("a = %d & b = %d", a, b);

	FILE *FileOut;// khai báo file

	FileOut = fopen("Output.txt", "w");// mở tập tin để ghi

	int Tong = a + b;
	int Hieu = a - b;
	int Tich = a * b;
	float Thuong = (float)a / b;

	fprintf(FileOut, "\n%d + %d = %d", a, b, Tong);
	fprintf(FileOut, "\n%d - %d = %d", a, b, Hieu);
	fprintf(FileOut, "\n%d * %d = %d", a, b, Tich);
	fprintf(FileOut, "\n%d / %d = %f", a, b, Thuong);

	fclose(FileOut);// đóng tập tin


	_getch();
	return 0;
}