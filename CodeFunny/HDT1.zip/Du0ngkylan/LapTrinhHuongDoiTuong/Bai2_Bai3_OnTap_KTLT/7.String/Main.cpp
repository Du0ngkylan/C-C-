﻿/*
Bên C: char c[100];
Bên C++ : string 

*/

#include<iostream>
#include<string>
using namespace std;

int main(){
	string s;// khai báo biến s kiểu string

	//s = "Ha Noi Ngay Mua ";
	//string s1 = "Dem Khong Trang";
	//s += s1;
	//s.erase(s.begin() + 3);
	//cout << s<<endl;

	cout << "\nNhap Ten Cua Ban: ";

	//cin >> s;
	getline(cin, s);

	cout << "\nChao Ban " << s<<endl;

	int dodai = s.length();

	cout << "\nDo Dai : " << dodai;

	system("pause");
	return 0;
}