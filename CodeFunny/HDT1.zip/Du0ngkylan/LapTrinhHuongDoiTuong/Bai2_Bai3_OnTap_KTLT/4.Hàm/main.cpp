﻿/*
Hàm có 2 dạng:
1. hàm không có trả về(void)
2. hàm có trả về(int,string,float,char...)

chú ý: hàm không trả về---> gọi là thủ tục

tham trị và tham chiếu:
+ Tham trị: void XuLy(int a);
+ Tham chieu : void XuLy(int &a);

*/




#include<iostream>
#include<string>
using namespace std;


void BienDoi(int &a){
	cout << "\nDia chi cua a trong ham bien doi: " << &a;
	a += 5;
}

void NHapDuLieu(float &Toan, float &Ly, float &Hoa){

	cout << "\nNhap Diem Toan: ";
	cin >> Toan;
	cout << "\nNhap Diem Ly: ";
	cin >> Ly;
	cout << "\nNhap Diem Hoa: ";
	cin >> Hoa;
}

void XuatDuLieu(float Toan, float Ly, float Hoa){
	cout << "========================";
	cout << "\nDiem Toan: " << Toan;
	cout << "\nDiem Ly: " << Ly;
	cout << "\nDiem Hoa: " << Hoa;
}

float DiemTrungBinh(float Toan, float Ly, float Hoa){
	return(Toan + Ly + Hoa) / 3;
}

string XepLoai(float DTB){
	if (DTB < 4.5){
		return "Yeu";
	}
	else if (DTB >= 4.5&&DTB < 6.5){
		return "Trung Binh";
		}
	else if (DTB >= 6.5&& DTB < 8){
		return "kha";
	}
	return "Gioi";
}

int main(){
	/*int a=10;
	cout << "\nDia chi cua a trong ham main: " << &a;
	BienDoi(a);
	cout << "\na= "<<a<<endl;*/


	float Toan, Ly, Hoa;

	NHapDuLieu(Toan, Ly, Hoa);
	XuatDuLieu(Toan, Ly, Hoa);

	float DTB = DiemTrungBinh(Toan, Ly, Hoa);
	cout << "\nDiem Trung Binh: " << DTB;

	string xl = XepLoai(DTB);
	cout << "\nXep Loai: " << xl<<endl;



	system("pause");
	return 0;
}