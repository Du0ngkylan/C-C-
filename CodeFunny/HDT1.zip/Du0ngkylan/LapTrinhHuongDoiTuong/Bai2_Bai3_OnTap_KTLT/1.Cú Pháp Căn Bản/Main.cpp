﻿#include<iostream>
#include<ctime>

using namespace std;

// không nên dùng void main vì không chạy được ở các trình biên dịch cao
int main(){
	// Nhập xuất

	cout << "Xin Chao Moi Nguoi!"<<endl;

	int namsinh,namhientai, tuoi;

	cout << "\nNhap Nam sinh: ";
	cin >> namsinh;

	time_t t = time(0);
	struct tm*Now = localtime(&t);
	namhientai = Now->tm_year + 1900;

	tuoi = namhientai - namsinh;

	cout << "\nBan Sinh Nam " << namsinh << " => Ban " << tuoi << " Tuoi" << endl;


	system("pause");// dừng màn hình để xem kết quả
	return 0;
}

/*int main(int argc,char *argv )
---->hàm main bản chất cũng là hàm
---->tham số dòng lệnh
*/