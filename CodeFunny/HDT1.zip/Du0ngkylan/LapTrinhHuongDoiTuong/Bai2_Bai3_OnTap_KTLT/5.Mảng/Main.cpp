﻿/*
Mảng 1 chiều:
-là 1 dãy các ô nhớ liên tục đánh số từ 0-->n-1(mảng có n phần tử)
-Mảng có 2 dạng:
	+ mảng tĩnh: cấp phát trước 1 số cụ thể
	+mảng động : cần dùng bao nhiêu thì cấp phát bấy nhiêu

*/

/*Mảng Tĩnh*/

#include<iostream>
using namespace std;
//#define MAX 100
void NhapMang(int *a, int n){
	for (int i = 0; i < n; i++){
		cout << "a[" << i << "]= ";
		cin >> a[i];
	}
}

void XuatMang(int *a, int n){
	cout << "\nMang Vua Nhap La: ";
	for (int i = 0; i < n; i++){
		cout << a[i]<<'\t';
	}
}

int TinhTong(int *a, int n){
	int Tong=0;
	for (int i = 0; i < n; i++){
		if (a[i] % 2 == 0){
			Tong += a[i];
		}
	}
	return Tong;
}

int main(){
	int n = 6;
	int *a = new int[n];// cấp phát mảng có n phần tử
	NhapMang(a, n);
	XuatMang(a, n);

	int TongChan = TinhTong(a, n);
	cout << "\nTong Cac So Chan Trong Mang La: " << TongChan<<endl;

	delete[] a;// giải phóng bộ nhớ
	system("pause");
	return 0;
}