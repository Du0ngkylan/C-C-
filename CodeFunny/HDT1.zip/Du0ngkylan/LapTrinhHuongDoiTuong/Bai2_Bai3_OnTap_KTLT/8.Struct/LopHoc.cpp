﻿#include"LopHoc.h"


void NhapLopHoc(LOPHOC &lh){

	int luachon;
	do{
		cout << "\n         --------Menu-------              \n";
		cout << "\n1. Nhap";
		cout << "\n2. Thoat";
		cout << "\n----      --------     ------        -----\n";

		cout << "\nNhap Vao Lua Chon Cua Ban: ";
		cin >> luachon;

		if (luachon == 1){

			SINHVIEN sv;
			NhapSinhVien(sv);
			lh.arr.push_back(sv);// thêm vào 1 sinh viên
		}

	} while (luachon!=2);

}


void XuatLopHoc(LOPHOC lh){

	int size = lh.arr.size();// lấy ra số lượng sinh viên trong mảng

	for (int i = 0; i < size; i++){

		cout << "\nThong Tin Sinh Vien Thu " << i + 1 << " la: ";
		XuatSinhVien(lh.arr[i]);// xuất ra sinh viên
	}
}



float Timdiemtrungbinh_Max(LOPHOC lh){

	float Dtb_Max = TinhDiemTrungBinh(lh.arr[0]);

	int size = lh.arr.size();
	for (int i = 0; i < size; i++){

		float DTB = TinhDiemTrungBinh(lh.arr[i]);
		
		if (DTB > Dtb_Max){
			Dtb_Max = DTB;
		}
	}

	return Dtb_Max;
}


void Xuathongtinsinhviendiemtrungbinh_Max(LOPHOC lh){

	float DtbMax = Timdiemtrungbinh_Max(lh);

	int size = lh.arr.size();
	for (int i = 0; i < size; i++){

		if (TinhDiemTrungBinh(lh.arr[i]) == DtbMax){

			XuatSinhVien(lh.arr[i]);

			cout << "\n\n";
		}
	}
}