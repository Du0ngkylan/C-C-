﻿#include"CNgay.h"// ánh xạ 

void NhapNgay(NGAY &x){
	cout << "\nNhap Vao Ngay: ";
	cin >> x.ngay;

	cout << "\nNhap Vao Thang: ";
	cin >> x.thang;

	cout << "\nNhap Vao Nam: ";
	cin >> x.nam;
}

void XuatNgay(NGAY x){
	cout << "\nNgay " << x.ngay << " Thang " << x.thang << " Nam " << x.nam;

}