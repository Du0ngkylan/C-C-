﻿#include"SinhVien.h"// ánh xạ

void NhapSinhVien(SINHVIEN &sv){

	fflush(stdin);
	cout << "\nNhap Ma So:  ";
	getline(cin, sv.MaSo);

	fflush(stdin);// xóa bộ nhớ đệm trước khi sử dụng getline
	cout << "\nNhap Ho Ten: ";
	getline(cin, sv.HoTen);

	cout << "\nNhap Vao Ngay Sinh: ";
	NhapNgay(sv.ngaysinh);

	cout << "\nNhap Diem Toan: ";
	cin >> sv.Toan;

	cout << "\nNhap Diem Ly: ";
	cin >> sv.Ly;

	cout << "\nNhap Diem Hoa: ";
	cin >> sv.Hoa;

}

void XuatSinhVien(SINHVIEN sv){

	cout << "\n-------------------------------------------------------\n";
	cout << "\nMa So Sinh Vien: " << sv.MaSo;
	cout << "\nHo Ten: " << sv.HoTen;
	cout << "\nNgay Sinh: ";
	XuatNgay(sv.ngaysinh);
	cout << "\nDiem Toan Ly Hoa La: " << sv.Toan << "  " << sv.Ly << "  " << sv.Hoa;
	cout << "\nDiem Trung Binh : " << TinhDiemTrungBinh(sv) << endl;


}

float TinhDiemTrungBinh(SINHVIEN sv){
	return(sv.Toan + sv.Ly + sv.Hoa) / 3;
}