﻿#pragma once // tránh đụng độ thư viện
#include<iostream>
using namespace std;

struct Ngay{
	int ngay, thang, nam;

};

typedef struct Ngay NGAY;

void NhapNgay(NGAY &);
void XuatNgay(NGAY);