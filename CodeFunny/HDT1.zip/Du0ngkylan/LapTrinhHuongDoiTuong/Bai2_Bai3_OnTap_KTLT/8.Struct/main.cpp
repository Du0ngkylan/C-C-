﻿/*
Bài Tập: Viết chương trình quản lý danh sách các sinh viên có trong lớp học
biêt thông tin mỗi sinh viên gồm có:
+ Mã số, họ tên
+ Điểm toán, lý , hóa
+ Ngày sinh
+ tính điểm trung bình và xuất thông tin sinh viên có điểm trung bình cao nhất lớp


*/
#include"LopHoc.h"

int main(){

	LOPHOC lh;
	NhapLopHoc(lh);
	XuatLopHoc(lh);

	cout << "\nThong Tin Cac Sinh Vien Co Diem Trung Binh Max La: ";
	Xuathongtinsinhviendiemtrungbinh_Max(lh);


	system("pause");
	return 0;
}