﻿#include"SinhVien.h"
#include<vector>


struct LopHoc{

	vector<SINHVIEN> arr;// khai báo 1 mảng sinh viên
};

typedef struct LopHoc LOPHOC;

void NhapLopHoc(LOPHOC &);
void XuatLopHoc(LOPHOC);
float Timdiemtrungbinh_Max(LOPHOC);
void Xuathongtinsinhviendiemtrungbinh_Max(LOPHOC);