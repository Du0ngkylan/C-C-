#include"CNgay.h"
#include<string>


struct SinhVien{
	string MaSo, HoTen;
	NGAY ngaysinh;
	float Toan, Ly, Hoa;
};

typedef struct SinhVien SINHVIEN;

void NhapSinhVien(SINHVIEN &);
void XuatSinhVien(SINHVIEN);
float TinhDiemTrungBinh(SINHVIEN);