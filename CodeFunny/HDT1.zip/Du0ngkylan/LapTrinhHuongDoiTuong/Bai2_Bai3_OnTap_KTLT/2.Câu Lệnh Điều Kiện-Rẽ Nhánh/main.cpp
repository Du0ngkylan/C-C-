#include<iostream>

using namespace std;


int main(){

	int a = 8, b = 6;
	int min, max;

	//c�ch 1:
	min = a < b ? a : b;
	max = a>b ? a : b;

	//c�ch 2:

	if (a > b){
		min = b;
		max = a;
	}
	else{
		min = a;
		max = b;
	}

	cout << "\nCho 2 so: " << a << " va " << b;
	cout << "\nMin= " << min << "\nMax= " << max << endl;

	system("pause");
	return 0;
}