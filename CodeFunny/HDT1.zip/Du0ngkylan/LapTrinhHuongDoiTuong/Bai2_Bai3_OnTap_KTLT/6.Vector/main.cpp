﻿
/*
Nằm trong bộ thư viện STL gồm có:
+Vector
+List
+Stack
+Queue
+String
*/




#include<iostream>
#include<vector>
using namespace std;


int main(){

	vector<int> arr;   //đặt tên cho vector
	int n = 5;

	//cấp phát trước bộ nhớ
	arr.resize(n);

	for (int i = 0; i < n; i++){
		arr[i] = i + 1;
	}

	//arr.push_back(6);

	//thêm phần tử có giá trị 100 vào vị trí 2
	arr.insert(arr.begin() + 2, 100);


	// xóa phần tử ở vị trí 3
	arr.erase(arr.begin() + 3);

	int size = arr.size();   // lấy số lượng phần tử đang chứa

	cout << "\nSo Luong Phan Tu Trong Vector La: " << size << endl;

	for (int i = 0; i < size; i++){
		cout << arr[i] << '\t';
	}

	system("pause");
	return 0;
}