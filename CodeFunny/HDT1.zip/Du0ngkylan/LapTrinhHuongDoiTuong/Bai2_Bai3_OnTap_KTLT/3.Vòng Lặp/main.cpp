﻿/*
vòng lặp chính thống có 3 dạng:
1. for(<khởi tạo> ; <điều kiện lặp> ; <bước lặp>)
2.while
cú pháp:
<khởi tạo>;
while(<điều kiện lặp>){

	<bước lặp>;
}
3. do while
cú pháp:

<khởi tạo>;
do{
	<hành động>
	<bước lặp>

}while(<điều kiện lặp>);



===>> ngoài ra còn có vòng lặp goto


*/



#include<iostream>
#include<conio.h>
using namespace std;

int main(){

	// ví dụ tính tổng 
	int tong = 0;

	/*for (int i = 1; i <= 10; i++){
		tong += i;
	}
	*/

	/*int i = 1;
	while (i <= 10){
		tong += i;
		i++;
	}

	cout << "\nTong = " << tong<<'\n';
	*/


	// ví dụ nhập điểm của học sinh

	float diem;
	/*
	duongkylan:
	do{
		cout << "\nNhap Vao Diem Cua Hoc Sinh: ";
		cin >> diem;
		if (diem<0 || diem>10){
			cout << "\nDiem Nhap Khong Hop Le,Vui Long Kiem Tra Lai!"<<endl;

			system("pause");
			system("cls");
			goto duongkylan;
		}
	} while (diem<0||diem>10);
	*/

duongkylan:
	cout << "\nNhap vao diem so: ";
	cin >> diem;

	if (diem < 0 || diem > 10)
	{
		cout << "\nDiem so khong hop le. Xin kiem tra lai !";
		system("pause");
		system("cls");
		goto duongkylan;
	}

	cout << "\nBan co muon tiep tuc chay ? nhan phim c de tiep tuc chay, nhan phim bat ky khac de thoat ra? ";

	char x=_getch();
	if (x == 'c' || x == 'C')
	{
		system("cls");
		goto duongkylan;
	}
	
	system("pause");
	return 0;
}