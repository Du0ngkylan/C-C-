﻿#include<iostream>
#include<string>

using namespace std;

class HocSinh{
private:
	string ten;
	float *diem;

public:
	void Xuat(){
		cout << "\nTen: " << ten;
		cout << "\nDiem: " << *diem;
		
	}
	// khởi tạo mặc định

	HocSinh(){
		ten = "Mai Xuan Duong";
		diem = new float;// cấp vùng nhớ cho nó
		*diem = 8.5;
		cout << "\nok" << endl;
	}


	//khởi tạo có tham số
	HocSinh(string t, float d){
		ten = t;
		diem = new float;// cấp vùng nhớ cho nó
		*diem = d;
	}

	void ThayDoi(){
		(*diem)--;
	}

};

int main(){

	HocSinh hs1("Duong",7);
	HocSinh hs2(hs1);

	hs1.ThayDoi();
	hs2.Xuat();

	


	system("pause");
	return 0;
}