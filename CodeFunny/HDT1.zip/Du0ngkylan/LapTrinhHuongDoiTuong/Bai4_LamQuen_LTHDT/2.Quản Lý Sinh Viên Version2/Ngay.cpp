#include "Ngay.h"

void Ngay::Nhap(){
	cout << "\nNhap Ngay: ";
	cin >> ngay;
	cout << "\nNhap Thang: ";
	cin >> thang;
	cout << "\nNhap Nam: ";
	cin >> nam;
}

void Ngay::Xuat(){
	cout << "Ngay " << ngay << " Thang " << thang << " Nam " << nam;
}
