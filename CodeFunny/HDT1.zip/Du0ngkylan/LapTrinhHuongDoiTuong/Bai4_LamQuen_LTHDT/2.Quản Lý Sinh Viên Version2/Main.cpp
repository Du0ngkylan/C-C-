#include<iostream>
#include<string>
#include"HocSinh.h"

using namespace std;

int main(){

	HocSinh hs;
	hs.Nhap();
	hs.Xuat();
	
	float diemTB = hs.DTB();
		cout << "\nDiem Trung Binh: " << diemTB<<endl;


	system("pause");
	return 0;
}