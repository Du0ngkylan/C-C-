﻿#include "HocSinh.h"

/*
Cú Pháp:
<Kiểu dữ liệu><Tên lớp>::<Tên Phương Thức>

*/

void HocSinh::Nhap(){

	fflush(stdin);
	cout << "\nNhap Ten: ";
	getline(cin, ten);
	cout << "\nNhap Diem Toan: ";
	cin >> dToan;
	cout << "\nNhap Diem Van: ";
	cin >> dVan;

	cout << "\nNhap Ngay Sinh: ";
	ngaysinh.Nhap();
}

void HocSinh::Xuat(){
	cout << "\n----------------------------";
	cout << "\nTen: " << ten;
	cout << "\nDiem Toan: " << dToan;
	cout << "\nDiem Van: " << dVan;
	cout << "\nNgay Sinh: ";
	ngaysinh.Xuat();
}

float HocSinh::DTB(){
	return(dToan + dVan) / 2;
}