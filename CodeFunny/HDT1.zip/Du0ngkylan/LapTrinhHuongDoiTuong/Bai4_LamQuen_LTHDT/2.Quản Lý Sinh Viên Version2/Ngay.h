#pragma once
#include<iostream>
#include<string>

using namespace std;
class Ngay
{
private:
	int ngay, thang, nam;

public:
	void Nhap();
	void Xuat();
};

