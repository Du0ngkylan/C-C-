#pragma once
#include"Ngay.h"
#include<string>

using namespace std;

class HocSinh
{
private:
	string ten;
	float dToan, dVan;
	Ngay ngaysinh;

public:
	void Nhap();
	void Xuat();
	float DTB();
};

