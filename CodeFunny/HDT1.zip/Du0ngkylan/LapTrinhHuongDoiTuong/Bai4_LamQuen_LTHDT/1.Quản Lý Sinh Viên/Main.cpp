#include<iostream>
#include<string>
using namespace std;

class Ngay{
private:
	int ngay, thang, nam;
public:
	void Nhap(){
		cout << "\nNhap Ngay: ";
		cin >> ngay;

		cout << "\nNhap Thang: ";
		cin >> thang;

		cout << "\nNhap Nam: ";
		cin >> nam;

	}

	void Xuat(){
		cout << "\nNgay " << ngay << " thang " << thang << " nam " << nam;
	}

};


class HocSinh{
private:
	string ten;
	float dToan, dVan;
	Ngay ngaysinh;

public:
	void Nhap(){

		fflush(stdin);
		cout << "\nNhap Ten Hoc Sinh: ";
		getline(cin, ten);

		cout << "\nNhap Diem Toan: ";
		cin >> dToan;

		cout << "\nNhap Diem Van: ";
		cin >> dVan;

		cout << "\nNhap Ngay Sinh: ";
		ngaysinh.Nhap();
	}
	void Xuat(){
		cout << "--------------------------------------------";
		cout << "\nTen Hoc Sinh La: " << ten << "\nDiem Toan: " << dToan << "\nDiem Van: " << dVan;

		cout << "\nNgay Sinh: ";
		ngaysinh.Xuat();
	}

	float DTB(){
		return(dToan + dVan) / 2;
	}


};

int main(){

	HocSinh hs1;

	hs1.Nhap();
	hs1.Xuat();

	float diemTB = hs1.DTB();
	cout << "\nDiem Trung Binh: " << diemTB<<endl;

	system("pause");
	return 0;
}