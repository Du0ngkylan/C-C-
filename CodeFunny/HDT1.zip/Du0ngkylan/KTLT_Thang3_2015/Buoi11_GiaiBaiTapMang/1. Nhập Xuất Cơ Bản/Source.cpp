﻿#include<stdio.h>
#include<conio.h>
#define MAX 100

void NhapMang(int a[], int n){

	for (int i = 0; i < n; i++){
		printf_s("a[%d] = ", i);
		scanf_s("%d",&a[i]);
	}
}

void XuatMang(int a[], int n){

	for (int i = 0; i < n; i++){
		printf_s("%4d", a[i]);
	}
}

// Hãy Tìm phần tử âm lớn nhất, dương bé nhất trong mảng các số nguyên

int ViTriAmDauTien(int a[], int n){
	for (int i = 0; i < n; i++){
		if (a[i] < 0){
			return i;
		}
	}
	return -1;
}

int PhanTuAmLonNhat(int a[], int n , int ViTriAmDauTien){

	
	int PhanTuAmMax = a[ViTriAmDauTien];

	for (int i = ViTriAmDauTien + 1; i < n; i++){

		if (a[i] < 0 && a[ViTriAmDauTien] < a[i]){
			PhanTuAmMax = a[i];
		}
	}

	return PhanTuAmMax;
}

int main(){

	int a[MAX], n;
	do{
		printf_s("\nNhap Vao So Phan Tu : ");
		scanf_s("%d", &n);
		if (n < 0 || n > MAX){
			printf_s("\nSo Luong Phan Tu Khong Hop Le.Kiem Tra Lai!");
		}
	} while (n < 0 || n > MAX);

	NhapMang(a, n);
	printf("\nMang Vua Nhap La: ");
	XuatMang(a, n);


	int vitriamdau = ViTriAmDauTien(a, n);

	if (vitriamdau == -1){
		printf_s("\nKhong Co Phan Tu Am Trong Mang");
	}
	else{

		int AmMax = PhanTuAmLonNhat(a, n, vitriamdau);

		printf_s("\nPhan Tu Am Lon Nhat Mang La: %d", AmMax);
	}

	_getch();
	return 0;
}