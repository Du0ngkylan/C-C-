#include<iostream>


using namespace std;

int main(){
	int nam;
	char a, b, c, d, e;
	
	cout << "\nNhap vao Nam= ";
	cin >> nam;
	cin.ignore(1);
	cin.get(a);
	cin.ignore(1);
	cin.get(b);
	cin.ignore(1);
	cin.get(c);
	cin.ignore(1);
	cin.get(d);
	cin.ignore(1);
	cin.get(e);
	
	cout <<a<<b<<c<<d<<e<<" Nam "<< nam<<endl;



	system("pause");
	return 0;
}