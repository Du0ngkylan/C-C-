﻿#include<iostream>

using namespace std;

int main(){
	float a, b,c;
	char dau;
	cout << "\nNhap Vao 2 So a va b:  ";
	cin >> a >> b;
	cout << "\nNhap vao Dau Cua Bieu Thuc: ";
	cin >> dau;

	switch (dau)
	{
	case'-':c = a - b;
		break;
	case '+':c = a + b;
		break;
	case'*':case'x':case'.':c = a*b;
		break;
	case'/':c = a / b;
		break;
	default:
		cout << "\nKhong Hop Le!";
		break;
	}

	cout << "\nKet Qua Bieu Thuc La: " << c<<endl;

	system("pause");
	return 0;
}