﻿#include<iostream>
#include<string>
#include<iomanip>// sử dụng các định dạng
using namespace std;
// cin.get(c) cho phép nhập vào 1 ký tự vào biến ký tự c
// cin.getline(s,n) cho phép nhập tối đa n-1 ký tự vào xâu s


int main(){
	
	cout << "\nCHI TIEU" << endl << "===============" << endl;
	cout << setiosflags(_IOSshowpoint) << setprecision(3);
	cout << "Sach Vo" << setw(20) << "20k" << endl;
	cout << "Quan Ao" << setw(20) << "50k" << endl;
	cout << "An Sang" << setw(20) << "100k" << endl;



	system("pause");
	return 0;
}

