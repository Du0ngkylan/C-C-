﻿#include<iostream>// khai báo tập nguyên mẫu để dùng được cout và cin

using namespace std;

int main(){
	float cd, cr;

duongkylan:
	cout << "\nMoi Ban Nhap vao chieu dai va chieu rong";
	// nhập xuất
	cout << "\nNhap Chieu Dai: "; cin >> cd;
	cout << "\nNhap Chieu Rong: "; cin >> cr;
	// xuất kết quả
	cout << "\nDienTich la: " << cd*cr;
	cout << "\nChu vi la: " << (cd + cr) * 2;
	cout << endl;

	goto duongkylan;

	system("pause");
	return 0;
}