#include<iostream>
#include<math.h>
using namespace std;

int main(){
	float a, b, c;
	float C,P, S, ha, ma, ga, r, R;
	do{
		cout << "\n\aNhap Do Dai Cua 3 Canh:  "<<endl;
		cin >> a >> b >> c;
		if (a < 0 || b < 0 || c < 0){
			cout<<"\nBan Nhap Khong Dung, Xin Kiem Tra Lai!";
		}
	} while (a<0||b<0||c<0);
	if (a + b <= c || b + c <= a || a + c <= b){
		cout << "\nKhong Phai Do Dai Cua Tam Giac";
	}
	else{
		P = (a + b + c) / 2;
		S = sqrt(P*(P-a)*(P-b)*(P-c));
		R = (a*b*c) / (4 * S);
		cout << "\nChu Vi Cua Tam Giac La: " << (a + b + c);
		cout << "\nDien Tich Tam Giac La: " << S;
		cout << "\nBan Kinh Duong Tron Ngoai Tiep Tam Giac la:  " << R;

	}





	system("pause");
	return 0;

}