﻿// Bài toán nhân 2 số theo phương pháp ấn độ
#include<iostream>
#include<math.h>

using namespace std;


int main(){
	int m, n, kq=0;
	cout << "\nNhap vao 2 so m va n: ";
	cin >> m >> n;
lap:
	if (m % 2)
		kq += n;
	m = m>> 1;
	n = n << 1;
	if (m)
		goto lap;

	cout << "\nKet Qua m nhan n : " << kq<<endl;
	system("pause");
	return 0;
}