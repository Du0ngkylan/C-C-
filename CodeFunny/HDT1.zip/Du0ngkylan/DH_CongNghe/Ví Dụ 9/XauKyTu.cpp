﻿/* xâu ký tự
cách khai báo:
char <Tên Xâu>[Độ Dài];            --------->không khởi tạo
char <Tên Xâu>[Độ Dài]=xâu ký tự;  -------->có khởi tạo
char <Tên Xâu>[]=xâu ký tự;        --------------> có khởi tạo

ví dụ: char HoTen[26];      ---> xâu họ tên chứa tối đa 25 kí tự
 char thang[]="mười hai";   ---> độ dài mảng =9


*/

#include<iostream>
#include<string>

using namespace std;

int main(){

	/*char s[] = "I\'m a student";
	cout << s<<endl;
	cout << s[0]<<endl;
	*/

	char c[10];
	cin.getline(c, 10);

	cout << c << endl;


	system("pause");
	return 0;
}