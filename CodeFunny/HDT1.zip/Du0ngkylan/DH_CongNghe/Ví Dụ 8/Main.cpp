#include<iostream>

using namespace std;

int main(){
	float a[100], min;
	int i, n;
	cout << "\nNhap So Phan Tu Cua Mang: ";
	cin >> n;
	for (i = 0; i < n; i++){
		cout << "a[" << i << "] = ";
		cin >> a[i];
	}
	min = a[0];
	
	for (i = 1; i < n; i++){
		if (min >= a[i]){
			min = a[i];
			
		}
	}
	cout << "\nPhan Tu Nho Nhat Mang La: " << min;
	cout << "\nO Vi Tri: ";
	for (i = 0; i < n; i++){
		if (a[i] == min)
			cout << i+1 << '\t';
	}
	/*if (min == a[0]){
		cout << "\nO Vi Tri: 1 ";
	}
	else{
		cout << "\nO Vi Tri: " << dem + 1;
	}*/


	system("pause");
	return 0;
}