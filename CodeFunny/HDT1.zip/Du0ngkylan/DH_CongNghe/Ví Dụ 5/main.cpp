#include<iostream>
#include<math.h>

using namespace std;

int main(){
	float a, b, c;
	float Delta, x1, x2;

	cout << "\nNhap vao a,b,c : ";
	cin >> a >> b >> c;
	Delta = b*b - 4 * a*c;
	if (Delta < 0){
		cout << "\nPhuong trinh : " << a << "x^2" << " + " << b << "x" << " + " << c << " = 0" << " Vo Nghiem"<<endl;
	}
	else{
		if (Delta==0){
			cout << "\nPhuong trinh : " << a << "x^2" << " + " << b << "x" << " + " << c << " = 0"<<endl;
			cout << "\nCo Nghiem Kep la: " << -b / (2 * a)<<'\n';
		}
		else{
			x1 = (-b + sqrt(Delta)) / (2 * a);
			x2 = (-b - sqrt(Delta)) / (2 * a);
			cout << "\nPhuong trinh : " << a << "x^2" << " + " << b << "x" << " + " << c << " = 0";
			cout << "\nCo 2 Nghiem La: " << x1 <<"  va  " << x2<<'\n';
		}
	}
	system("pause");
	return 0;
}