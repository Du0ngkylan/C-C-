﻿#include<iostream>
#include<algorithm>
#include<vector>

using namespace std;

int main(){

	vector <int> v;
	vector <int>::iterator It;

	// khởi tạo danh sách

	v.push_back(3);
	v.push_back(1);
	v.push_back(8);
	v.push_back(6);
	v.push_back(4);

	// in danh sách chưa sắp xếp

	cout << "Danh sach chua sap xep : ( ";
	for (It = v.begin(); It != v.end(); It++)
		cout << *It<<"  ";
	cout << ")" << endl;

	// sắp xếp danh sách
	sort(v.begin(), v.end());

	// in danh sách sau khi sắp xếp

	cout << "Danh sach sau khi sap xep : ( ";
	for (It = v.begin(); It != v.end(); It++)
		cout << *It << "  ";
	cout << ")" << endl;
	


	system("pause");
	return 0;
}