﻿#include<iostream>
using namespace std;

class point{
protected:
	// Thành phần dữ liệu
	int x, y;
public:
	// Hàm thiết lập
	point(){
		x = 0;
		y = 0;
	};
	point(int iX, int iY){
		x = iX;
		y = iY;
	};
	// Hàm Hủy
	~point(){
		cout << "Doi Tuong Da Duoc Huy Bo\n";
	};

	// Hàm thành phần

	void move(int dx, int dy);
	void display();



};

void point::move(int dx, int dy){
	x += dx;
	y += dy;
}

void point::display(){
	cout << "(" << x << "," << y << ")\n";
}



int main(){
	// cấp phát động p1
	point *p1 = new point();
	p1->move(20, 20);
	p1->display();

	// cấp phát tĩnh P2
	point p2;
	p2.move(10, 10);
	p2.display();

	delete p1;
	system("pause");
	return 0;
}