﻿#pragma once
#include"point.h"
class colored_point :public point
{
protected:
	int color;
public:
	// Hàm thiết lập
	colored_point();
	colored_point(int iX,int iY,int iC);

	// Hàm hủy
	~colored_point();

	// Định nghĩa lại hàm display

	void display();
};

