#include<iostream>
#include "point.h"
using namespace std;

point::point()
{
	x = 0;
	y = 0;
}

point::point(int iX,int iY)
{
	x = iX;
	y = iY;
}

void point::move(int dx, int dy){
	x += dx;
	y += dy;
}

void point::display(){
	cout << "(" << x << " , " << y << ")\n";
}

point::~point()
{
	cout << "Doi Tuong Da Duoc Huy Bo\n";
}
