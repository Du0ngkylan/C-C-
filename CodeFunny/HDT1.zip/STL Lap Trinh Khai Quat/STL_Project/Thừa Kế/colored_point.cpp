#include "colored_point.h"
#include<iostream>
using namespace std;

colored_point::colored_point()
{
	color = 36;
}

colored_point::colored_point(int iX,int iY,int iC)
{
	color = iC;
}

colored_point::~colored_point()
{
}

void colored_point::display(){
	cout << "(" << x << " , " << y << " : " << color << ")\n";
}
