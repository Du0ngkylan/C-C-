#include<iostream>
#include"point.h"
#include"colored_point.h"


using namespace std;
int main(){
	colored_point *p = new colored_point();
	p->move(20, 20);
	p->display();


	delete p;
	system("pause");
	return 0;
}