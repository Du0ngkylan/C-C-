﻿#pragma once
class point
{
protected:
	// Thành phần dữ liệu
	int x, y;
public:
	// Hàm thiết lập
	point();
	point(int iX, int iY);

	// Hàm Hủy
	~point();

	// Hàm thành phần
	void move(int dx, int dy);
	void display();
};

