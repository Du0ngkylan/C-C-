﻿#include<iostream>
using namespace std;


// Lớp cơ sở với hàm thành phần ảo DienTich()
class Hinh{
protected:
	int chieudai, chieurong;

public:

	virtual void DienTich(){
	}

};

class HinhChuNhat :public Hinh{


	void DienTich()
	{
		int dt = (chieudai * chieurong);
		cout << "Dien tich cua lop HinhChuNhat la: "<< endl;

	}

};

class TamGiac :public Hinh{
public:

	void DienTich()
	{
		int dt = (chieudai * chieurong / 2);
		cout << "Dien tich cua lop TamGiac la: "<< endl;
	}

};

int main(){

	Hinh *p2;
	//p1 = new HinhChuNhat();
	p2 = new TamGiac();
	p2->DienTich();

	HinhChuNhat hcn;
	p2 = &hcn;
	p2->DienTich();



	system("pause");
	return 0;
}