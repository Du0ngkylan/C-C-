﻿/*
Viết chương trình nhập vào 2 số phức.
tính Tổng,Hiệu,Tích của 2 số đó và xuất kết quả???
*/



#include<stdio.h>
#include<conio.h>
#include<math.h>


struct SoPhuc{
	float thuc, ao;
};

typedef struct SoPhuc SOPHUC;

void Nhap(SOPHUC &);
void Xuat(SOPHUC);
SOPHUC Tong(SOPHUC , SOPHUC );
SOPHUC Hieu(SOPHUC, SOPHUC);
SOPHUC Tich(SOPHUC, SOPHUC);

int main(){

	SOPHUC z1,z2,z3;
	Nhap(z1);
	Nhap(z2);

	z3 = Tong(z1, z2);
	printf_s("\nTong: ");
	Xuat(z3);
	
	z3 = Tich(z1, z2);
	printf_s("\nTich: ");
	Xuat(z3);


	_getch();
	return 0;
}


void Nhap(SOPHUC &x){
	printf_s("\nNhap Phan Thuc: ");
	scanf_s("%f", &x.thuc);
	printf_s("\nNhap Phan Ao: ");
	scanf_s("%f", &x.ao);

}

void Xuat(SOPHUC x){
	printf_s(" %0.1f + %0.1fi", x.thuc, x.ao);
}

SOPHUC Tong(SOPHUC x, SOPHUC y){

	SOPHUC temp;
	temp.thuc = x.thuc + y.thuc;
	temp.ao = x.ao + y.ao;
	return temp;
}

SOPHUC Tich(SOPHUC x, SOPHUC y){
	SOPHUC temp;

	temp.thuc = x.thuc * y.thuc - x.ao*y.ao;
	temp.ao = x.thuc*y.ao + x.ao*y.thuc;

	return temp;
}