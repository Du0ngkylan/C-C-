﻿/*
Viết Chương trình nhập vào một ngày.tìm ngày hôm qua và xuất ra kết quả???
*/

#include<stdio.h>
#include<conio.h>


struct ngaythang{

	int ngay, thang, nam;
};
typedef struct ngaythang NGAY;



int main(){




	_getch();
	return 0;
}