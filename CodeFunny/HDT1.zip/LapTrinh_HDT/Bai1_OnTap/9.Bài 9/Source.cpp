﻿/*
Viết chương trình nhập vào 2 phân số.
Tính tổng, hiệu,tích,thương giữa chúng và xuất kết quả.
*/

#include<stdio.h>
#include<conio.h>
#include<math.h>

struct phanso{

	int tu, mau;
};
typedef struct phanso PHANSO;

void Nhap(PHANSO &);
void Xuat(PHANSO);

PHANSO Tong(PHANSO, PHANSO);
PHANSO Hieu(PHANSO, PHANSO);
PHANSO Tich(PHANSO, PHANSO);
PHANSO Thuong(PHANSO, PHANSO);

int main(){

	PHANSO a, b,kq;
	Nhap(a);
	Nhap(b);
	printf_s("\n2 Phan So Vua Nhap La: ");
	Xuat(a);
	Xuat(b);

	kq = Tong(a, b);
	printf_s("\nTong: ");
	Xuat(kq);

	kq = Hieu(a, b);
	printf_s("\nHieu: ");
	Xuat(kq);

	kq = Tich(a, b);
	printf_s("\nTich: ");
	Xuat(kq);

	kq = Thuong(a, b);
	printf_s("\nThuong: ");
	Xuat(kq);

	_getch();
	return 0;
}


void Nhap(PHANSO &x){
	printf_s("\nNhap tu: ");
	scanf_s("%d", &x.tu);
	do{
		printf_s("\nNhap Mau: ");
		scanf_s("%d", &x.mau);
		if (x.mau == 0){
			printf_s("\nMau So Phai Khac 0,xin hay nhap lai.");
		}
	} while (x.mau == 0);
}

void Xuat(PHANSO x){
	printf_s("\t%d / %d ", x.tu, x.mau);
}

PHANSO Tong(PHANSO a, PHANSO b){
	PHANSO temp;
	temp.tu = a.tu*b.mau + b.tu*a.mau;
	temp.mau = a.mau*b.mau;
	return temp;

}

PHANSO Hieu(PHANSO a, PHANSO b){
	PHANSO temp;
	temp.tu = a.tu*b.mau - b.tu*a.mau;
	temp.mau = a.mau*b.mau;
	return temp;

}

PHANSO Tich(PHANSO a, PHANSO b){
	PHANSO temp;
	temp.tu = a.tu * b.tu;
	temp.mau = a.mau*b.mau;
	return temp;

}

PHANSO Thuong(PHANSO a, PHANSO b){
	PHANSO temp;
	temp.tu = a.tu*b.mau;
	temp.mau = a.mau*b.tu;
	return temp;

}