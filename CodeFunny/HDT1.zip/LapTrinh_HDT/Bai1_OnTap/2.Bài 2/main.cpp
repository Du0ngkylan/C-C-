﻿/*
Viết chương trình nhập vào 1 ngày .tìm ngày kế tiếp và xuất ra kết quả???
*/


#include<stdio.h>
#include<conio.h>

struct ngaythang
{
	int ngay, thang, nam;
};

typedef struct ngaythang NGAY;

void Nhap(NGAY &);
void Xuat(NGAY );

int ktra_Namnhuan(NGAY );
NGAY KeTiep(NGAY );

NGAY HomQua(NGAY );

int sttTrongNam(NGAY );
long SoThuTu(NGAY );
NGAY TimNgay(int , int );
NGAY TimNgay(long );

int main(){

	NGAY x;
	Nhap(x);
	NGAY kq = KeTiep(x);
	printf_s("\nNgay Ban Dau: ");
	Xuat(x);
	printf_s("\nNgay ke tiep : ");
	Xuat(kq);


	_getch();
	return 0;

}

void Nhap(NGAY &x){
	printf_s("\nNhap ngay: ");
	scanf_s("%d", &x.ngay);
	printf_s("\nNhap thang: ");
	scanf_s("%d", &x.thang);
	printf_s("\nNhap nam: ");
	scanf_s("%d", &x.nam);
}

void Xuat(NGAY x){
	printf_s("\nNgay %d Thang %d Nam %d", x.ngay, x.thang, x.nam);
}


int ktra_Namnhuan(NGAY x){

	if (x.nam % 4 == 0 && x.nam % 100 != 0)
		return 1;
	if (x.nam % 400 == 0)
		return 1;
	return 0;
}


NGAY KeTiep(NGAY x){

	int NgayThang[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	if (ktra_Namnhuan(x) == 1)
		NgayThang[1] = 29;

	x.ngay++;

	if (x.ngay > NgayThang[x.thang - 1]){

		x.thang++;
		if (x.thang > 12){
			x.nam++;
			x.thang = 1;
		}

		x.ngay = 1;
	}

	return x;
}


NGAY HomQua(NGAY x)
{
	int NgayThang[12] = { 31, 28, 31,
		30, 31, 30, 31, 31, 30, 31, 30, 31 };
	if (ktra_Namnhuan(x) == 1)
		NgayThang[1] = 29;
	x.ngay--;
	if (x.ngay == 0)
	{
		x.thang --;
		if (x.thang == 0)
		{
			x.nam--;
			x.thang = 12;
		}
		x.ngay = NgayThang[x.thang - 1];
	}
	return x;
}


int sttTrongNam(NGAY x)
{
	int ngaythang[12] = { 31, 28, 31,
		30, 31, 30, 31, 31, 30, 31, 30, 31 };
	if (ktra_Namnhuan(x) == 1)
		 ngaythang[1] = 29;

	 int stt = 0;
	 for (int i = 1; i <= x.thang - 1; i++)
		 stt = stt + ngaythang[i - 1];
		 return (stt + x.ngay);
}

long SoThuTu(NGAY x)
{
	long stt = 0;
	for (int i = 1; i <= x.nam - 1; i++)
	{
		stt = stt + 365;
		NGAY temp = { 1, 1, i };
		if (ktra_Namnhuan(temp) == 1)
			stt = stt + 1;
	}
	return (stt + sttTrongNam(x));

}


NGAY TimNgay(int nam, int stt){
	int ngaythang[12] = { 31, 28, 31,
		30, 31, 30, 31, 31, 30, 31, 30, 31 };

	NGAY temp = { 1, 1, nam };

	if (ktra_Namnhuan(temp) == 1)
		 ngaythang[1] = 29;
	 temp.thang = 1;
	 while (stt - ngaythang[temp.thang - 1] >0)
		 {
		 stt = stt - ngaythang[temp.thang - 1];
		 temp.thang++;
		 }
	 temp.ngay = stt;
	 return temp;
 }

NGAY TimNgay(long stt)
{
	 int nam = 1;
	 int songay = 365;
	 while (stt - songay>0)
		 {
		 stt = stt - songay;
		 nam++;
		 songay = 365;
		 NGAY temp = { 1, 1, nam };
		 if (ktra_Namnhuan(temp) == 1)
			 songay = 366;
		}
	 return TimNgay(nam, (int)stt);
 }

//NGAY KeTiep(NGAY x){
//	long stt = SoThuTu(x);
//	stt = stt + 1;
//	 return TimNgay(stt);
// }