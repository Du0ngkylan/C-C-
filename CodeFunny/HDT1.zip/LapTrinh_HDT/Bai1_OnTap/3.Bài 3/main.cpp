﻿/*
Viết chương trình nhập vào tọa độ 2 điểm trong không gian.
tính khoảng cách và xuất ra kết quả?
*/



#include<stdio.h>
#include<conio.h>
#include<math.h>


struct ToaDo{
	float x, y, z;
};
typedef struct ToaDo TOADO;

void Nhap(TOADO &);
void Xuat(TOADO);
float KhoangCach(TOADO, TOADO );

int main(){

	TOADO a,b;

	printf_s("\nNhap Vao Toa Do Diem a:");
	Nhap(a);
	printf_s("\nNhap Vao Toa Do Diem b:");
	Nhap(b);
	printf_s("\nToa Do 2 Diem Vua Nhap La: ");
	Xuat(a);
	Xuat(b);

	float kc = KhoangCach(a, b);
	printf_s("\nKhoang Cach 2 Diem La: %0.2f", kc);


	_getch();
	return 0;
}

void Nhap(TOADO &a){
	printf_s("\nNhap x = ");
	scanf_s("%f", &a.x);
	printf_s("\nNhap y = ");
	scanf_s("%f", &a.y);
	printf_s("\nNhap z = ");
	scanf_s("%f", &a.z);
}

void Xuat(TOADO a){
	printf_s("\t( %0.2f , %0.2f , %0.2f )", a.x, a.y, a.z);

}

float KhoangCach(TOADO P, TOADO Q){

	return sqrt((Q.x - P.x)*(Q.x - P.x) + (Q.y - P.y)*(Q.y - P.y) + (Q.z - P.z)*(Q.z - P.z));
}