﻿/*
Viết chương trình nhập vào 2 phân số.
tìm phân số lớn nhất và kết quả???
*/


#include<stdio.h>
#include<conio.h>
#include<math.h>

struct PhanSo{
	int tu, mau;
};
typedef struct PhanSo PHANSO;

void Nhap(PHANSO &);
void Xuat(PHANSO);
int SoSanh(PHANSO, PHANSO);


int main(){

	PHANSO a,b;
	printf_s("\nNhap Phan So a: ");
	Nhap(a);
	printf_s("\nNhap Phan So b: ");
	Nhap(b);

	int kq = SoSanh(a, b);
	if (kq >= 0){
		Xuat(a);
	}
	else
	{
		Xuat(b);
	}


	_getch();
	return 0;
}

void Nhap(PHANSO &x){
	printf_s("\nNhap Tu: ");
	scanf_s("%d", &x.tu);
	printf_s("\nNhap Mau: ");
	scanf_s("%d", &x.mau);
}

void Xuat(PHANSO x){
	printf_s("\nPhan So lon nhat la: %d / %d", x.tu, x.mau);
}

int SoSanh(PHANSO x, PHANSO y){
	int kq;
	float a = (float)x.tu / x.mau;
	float b = (float)y.tu / y.mau;

	if (a > b)
		kq = 1;
	if (a < b)
		kq = -1;
	if (a == b)
		kq = 0;
	return kq;
}