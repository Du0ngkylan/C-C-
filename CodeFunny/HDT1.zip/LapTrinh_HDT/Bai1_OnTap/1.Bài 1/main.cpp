﻿/*
Đề bài: viết chương trình nhập vào một phân số .
		hãy cho biết phân số đó là âm hay dương hay bằng 0
*/


#include<stdio.h>
#include<conio.h>
#include<math.h>

struct phanso{
	int tu;
	int mau;
};

typedef struct phanso PHANSO;

void Nhap(PHANSO &);
void Xuat(PHANSO);
int XetDau(PHANSO);

int main(){

	PHANSO x;
	Nhap(x);
	Xuat(x);
	

	int kq = XetDau(x);

	switch (kq)
	{
	case 1:
		printf_s("\nPhan So Duong");
		break;
	case -1:
		printf("\nPhan So Am");
		break;
	case 0:
		printf_s("\nPham So Bang 0");
	}


	_getch();
	return 0;
}


void Nhap(PHANSO &x){
	
		printf_s("\nNhap Tu So: ");
		scanf_s("%d", &x.tu);

		do{
		printf_s("\nNhap Mau So: ");
		scanf_s("%d", &x.mau);
		if (x.mau == 0){
			printf_s("\nMau So Phai Khac 0,xin nhap lai:");
		}
	} while (x.mau==0);
}

void Xuat(PHANSO x){

	printf_s("\nPhan So Vua Nhap La: %d / %d", x.tu, x.mau);
}
int XetDau(PHANSO x){
	int kq;
	if ((x.mau * x.mau) > 0){
		
		kq = 1;
	}
	if ((x.tu * x.mau) < 0){
		
		kq = -1;
	}
	if (x.tu*x.mau == 0){
		
		kq = 0;
	}
	return kq;
}