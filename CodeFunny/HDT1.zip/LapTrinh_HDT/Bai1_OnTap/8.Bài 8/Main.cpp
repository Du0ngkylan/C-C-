﻿/*
Viết chương trình nhập tọa độ tâm và bán kính của đường tròn.
tính chu vi, diện tích của đường tròn.

*/

#include<stdio.h>
#include<conio.h>
#include<math.h>

struct diem{
	float x, y;
};
typedef struct diem DIEM;

struct duongtron{
	DIEM I;
	float R;
};
typedef struct duongtron DUONGTRON;

void Nhap(DIEM &);
void Xuat(DIEM);

void Nhap(DUONGTRON &);
void Xuat(DUONGTRON);

float DienTich(DUONGTRON);
float ChuVi(DUONGTRON);


int main(){

	DUONGTRON c;
	Nhap(c);
	Xuat(c);

	float cv = ChuVi(c);
	printf("\nChu Vi Duong Tron La: %0.2f", cv);
	float dt = DienTich(c);
	printf("\nDien Tich Duong Tron La: %0.2f", dt);

	_getch();
	return 0;
}

// nhập tọa độ
void Nhap(DIEM &p){
	printf_s("\nNhap x: ");
	scanf_s("%f", &p.x);
	printf_s("\nNhap y: ");
	scanf_s("%f", &p.y);

}
void Xuat(DIEM p){
	printf_s("( %0.2f , %0.2f )", p.x,p.y);

}
void Nhap(DUONGTRON &c){
	printf_s("\nNhap Tam: ");
	Nhap(c.I);
	printf_s("\nNhap Ban Kinh: ");
	scanf_s("%f", &c.R);

}
void Xuat(DUONGTRON c){
	printf_s("\nTam: ");
	Xuat(c.I);

	printf_s("\nBan Kinh: %0.2f", c.R);

}

float DienTich(DUONGTRON c){

	return (float)(c.R*c.R*3.14);
}
float ChuVi(DUONGTRON c){

	return (float)(2 *3.14 *c.R);
}