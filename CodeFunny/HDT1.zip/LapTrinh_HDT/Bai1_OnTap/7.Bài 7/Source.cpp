﻿/*
Viết chương trình nhập tọa độ 3 đỉnh A,B,C của tam giác trong hệ tọa độ Oxy.
tính chu vi, diện tích và tìm tọa độ trọng tâm

*/


#include<stdio.h>
#include<conio.h>
#include<math.h>

struct diem{
	float x, y;
};
typedef struct diem DIEM;

struct TamGiac{
	DIEM A;
	DIEM B;
	DIEM C;
};

typedef struct TamGiac TAMGIAC;

void Nhap(DIEM &);
void Xuat(DIEM );
float KhoangCach(DIEM, DIEM);

void Nhap(TAMGIAC &);
void Xuat(TAMGIAC);
float ChuVi(TAMGIAC);
float DienTich(TAMGIAC);
DIEM TrongTam(TAMGIAC);

int main(){

	TAMGIAC TG;
	Nhap(TG);
	Xuat(TG);

	float cv = ChuVi(TG);
	printf_s("\nChu Vi Cua Tam Giac La: %0.2f", cv);

	float dt = DienTich(TG);
	printf_s("\nDien Tich Cua Tam Giac La: %0.2f", dt);

	_getch();
	return 0;
}

void Nhap(DIEM &a){
	printf_s("\nNhap x = ");
	scanf_s("%f", &a.x);
	printf_s("\nNhap y = ");
	scanf_s("%f", &a.y);
}
void Xuat(DIEM a){
	printf_s("( %0.2f , %0.2f )", a.x, a.y);
}
float KhoangCach(DIEM P, DIEM Q){

	return sqrt((P.x - Q.x)*(P.x - Q.x) + (P.y - Q.y)*(P.y - Q.y));
}

void Nhap(TAMGIAC &t){
	printf_s("\nNhap A: ");
	Nhap(t.A);
	printf_s("\nNhap B: ");
	Nhap(t.B);
	printf_s("\nNhap C: ");
	Nhap(t.C);

}
void Xuat(TAMGIAC t){

	printf("\n A: ");
	Xuat(t.A);
	printf("\n B: ");
	Xuat(t.B);
	printf("\n C: ");
	Xuat(t.C);
}
float ChuVi(TAMGIAC t){

	float a = KhoangCach(t.B, t.C);
	float b = KhoangCach(t.A, t.C);
	float c = KhoangCach(t.A, t.B);

	return (a + b + c);
}
float DienTich(TAMGIAC t){
	float a = KhoangCach(t.B, t.C);
	float b = KhoangCach(t.A, t.C);
	float c = KhoangCach(t.A, t.B);

	float p = (a + b + c) / 2;

	return sqrt((p - a)*(p - b)*(p - c));

}
DIEM TrongTam(TAMGIAC t){
	DIEM temp;

	temp.x = (t.A.x + t.B.x + t.C.x) / 3;
	temp.y = (t.A.y + t.B.y + t.C.y) / 3;

	return temp;
}