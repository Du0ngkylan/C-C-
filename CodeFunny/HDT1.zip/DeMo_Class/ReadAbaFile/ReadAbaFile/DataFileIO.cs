﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ReadAbaFile
{
   
    class DataFileIO
    {
        public string strPathFile = "ab.inp";
        Region region = new Region();

        public List<string> ListAbaFiles()
        {
            List<string> FileList = new List<string>();




            return FileList;
        }

        public void ReadAbaQus()
        {
            using (StreamReader sr = new StreamReader(strPathFile))
            {
                string strLine = string.Empty;
                while ((strLine = sr.ReadLine()) != null)
                {
                    //Console.WriteLine(line);
                    if(strLine.Contains("*Surface"))
                    {
                        string strBoundaryName = strLine.Substring(strLine.LastIndexOf("=") + 1);
                        region.LstBoundary.Add(strBoundaryName);

                    }
                    else if(strLine.Contains("*Material"))
                    {
                        string strZoneName = strLine.Substring(strLine.LastIndexOf("=") + 1);
                        region.LstZone.Add(strZoneName);
                    }

                }
            }
        }
    }
}
