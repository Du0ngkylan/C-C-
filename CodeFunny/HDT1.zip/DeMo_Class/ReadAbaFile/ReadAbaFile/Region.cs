﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadAbaFile
{
    public class Region
    {
        string strRegionName;

        public string StrRegionName
        {
            get { return strRegionName; }
            set { strRegionName = value; }
        }

        List<string> lstZone = new List<string>();

        public List<string> LstZone
        {
            get { return lstZone; }
            set { lstZone = value; }
        }


        List<string> lstBoundary = new List<string>();

        public List<string> LstBoundary
        {
            get { return lstBoundary; }
            set { lstBoundary = value; }
        }

    }
}
