#include <iostream>
#include <conio.h>

using namespace std;

class NGUOI
{
protected:
	char ht[30], gt[5];
	int ngay, thang, nam;
public:
	void nhap()
	{
		cout << "\n nhap ho ten:";
		cin.ignore();
		cin.getline(ht, 30);
		cout << "\n nhap gioi tinh:";
		cin >> gt;
		cout << "\n nhap ngay sinh:";
		cin >> ngay >> thang >> nam;
	}
	void in()
	{
		cout << ht;
		cout << gt;
		cout << ngay << "-" << thang << "-" << nam;
		cout << endl;
	}
};
class SV :public NGUOI
{
private:  char lop[15], msv[15];
		  float dtb;

public:
	void nhap()
	{
		NGUOI::nhap();
		cout << "\n nhap ma sinh vien:"; cin >> msv;
		cout << "\n nhap lop:"; cin >> lop;
		cout << "\n nhap dtb:"; cin >> dtb;
	}
	void in()
	{
		NGUOI::in();
		cout << msv;
		cout << lop;
		cout << dtb;
		cout << endl;
	}
};
class GV : public NGUOI
{
private:
	float hsl;
	char dv[15];
public:
	void nhap()
	{
		NGUOI::nhap();
		cout << "\n nhap he so luong:"; cin >> hsl;
		cout << "\n nhap don vi:"; cin >> dv;
	}
	void in()
	{
		NGUOI::in();
		cout << hsl;
		cout << dv;
		cout << endl;
	}
};


int main()
{
	SV a[100];
	GV b[100];
	int n,m;

	cout << "\n nhap so luong sinh vien:";
	cin >> n;

	for (int i = 1; i <= n; i++)
	{
		cout << "sinh vien thu" << i << "la:";
		a[i].nhap();
	}


	cout << "\n nhap so luong giang vien:";
	cin >> m;

	for (int j = 1; j <= m; j++)
	{
		cout << "Giang vien thu" << j << "la:";
		b[j].nhap();
	}


	for (int i = 1; i <= n; i++)
		a[i].in();

	for (int j = 1; j <= n; j++)
		b[j].in();

	system("pause");
	return 0;
}