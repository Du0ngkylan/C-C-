#include "PHIEU.h"


PHIEU::PHIEU()
{
	soPhieu = 0;
	ngayLap = "";
	lyDo = "";
	TaiKhoanNo = 0;
	TaiKhoanCo = 0;
}

void PHIEU::Nhap()
{
	cout << "\nNhap So Phieu:";
	cin >> soPhieu;
	for (int i = 0; i < soPhieu; i++)
	{
		cin.ignore();
		cout << "\nNhap Thong Tin Phieu Thu " << i + 1 << ":" << endl;
		cout << "\nNgay Lap: "; cin >> ngayLap;
		cout << "\nLy Do: "; cin >> lyDo;
		cout << "\nTaiKhoanNo: "; cin >> TaiKhoanNo;
		cout << "\nTaiKhoanCo: "; cin >> TaiKhoanCo;
	}
}

void PHIEU::In()
{
	for (int i = 0; i < soPhieu; i++)
	{
		cout << "\nThong Tin Phieu Thu " << i + 1 << ":" << endl;
		cout << "Ngay Lap: " << ngayLap << endl;
		cout << "Ly Do: " << lyDo << endl;
		cout << "TaiKhoanNo: " << TaiKhoanNo << endl;
		cout << "TaiKhoanCo: " << TaiKhoanCo << endl;
	}
}


PHIEU::~PHIEU()
{
}
