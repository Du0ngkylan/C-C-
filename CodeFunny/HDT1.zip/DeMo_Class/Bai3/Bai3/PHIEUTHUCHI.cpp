#include "PHIEUTHUCHI.h"


PHIEUTHUCHI::PHIEUTHUCHI()
{
	maNV = "";
	tenNV="";
	DiaChi = "";
}


void PHIEUTHUCHI::Nhap()
{
	cout << "\nMaNV: "; cin >> maNV;
	cout << "\nTenNV: "; cin >> tenNV;
	cout << "\nDiaChi: "; cin >> DiaChi;
}


void PHIEUTHUCHI::In()
{
	cout << "MaNV: " << maNV << endl;
	cout << "TenNV: " << tenNV << endl;
	cout << "DiaChi: " << DiaChi << endl;
}


PHIEUTHUCHI::~PHIEUTHUCHI()
{
}
