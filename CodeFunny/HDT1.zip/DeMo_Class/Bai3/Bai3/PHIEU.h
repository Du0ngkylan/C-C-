#pragma once
#include<iostream>
#include<string>
using namespace std;

class PHIEU
{
protected:
	int soPhieu;
	string ngayLap, lyDo;
	int TaiKhoanNo, TaiKhoanCo;
public:
	PHIEU();
	void Nhap();
	void In();
	~PHIEU();
};

