﻿#include<iostream>
#include"PHIEU.h"
using namespace std;

int main()
{
	PHIEU *Phieu = new PHIEU();
	Phieu->Nhap();
	Phieu->In();


	system("pause");
	return 0;
}