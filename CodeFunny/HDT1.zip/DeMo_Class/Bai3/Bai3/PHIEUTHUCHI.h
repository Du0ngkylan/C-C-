#pragma once
#include"PHIEU.h"

class PHIEUTHUCHI:public PHIEU
{
private:
	string maNV,tenNV, DiaChi;
public:
	PHIEUTHUCHI();
	void Nhap();
	void In();
	~PHIEUTHUCHI();
};

