#include <stdio.h>
#include <conio.h>
#define max 100
#define  N 5

int a[N] = { 5, 3, 4, 7, 8 };
int b[N] = { 0, 0, 0, 0, 0 };

void InMangCon(){
	printf("\n[");
	for (int i = 1; i <= N; i++)
	{
		if (b[i] != 0)
		{
			printf(" %d ", a[i-1]);
		}
	}
	printf("]");
}

void MangCon(){
	int i = N;
	while (i != 0){
		InMangCon();
		i = N;
		while (b[i] == 1)
		{
			b[i] = 0;
			i--;
		}
		if (i > 0)
		{
			b[i] = 1;
		}
	}
}

int main()
{
	MangCon();
	_getch();
	return 0;
}