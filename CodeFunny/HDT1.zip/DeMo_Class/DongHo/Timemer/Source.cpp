#include<iostream>
using namespace std;

class time
{
private:
	int giay;
	int phut;
	int h;
public:
	int a, b, c;
	time(){ giay = 0; phut = 0; h = 0; }
	time(int a, int b, int c);
	void normalize();
	void advanced(int h_1, int m_1, int s_1);
	void printf();
	void reset(int, int, int);
};
time::time(int a, int b, int c)
{
	giay = a; phut = b; h = c;
	cout << h << phut << giay << endl;
	cout << "Khoi tao xong !" << endl;
}
void time::normalize()
{
	cout << "Nhap vao h , phut , giay ( 0 =< h <=23 , 0 =< phut <= 60 , 0 =< giay <= 60 , Chi lay so dung truoc dau cham dong ) \n";
	do{
		cout << "Nhap vao h = "; cin >> c; fflush(stdin);
		cout << "Nhap vau phut = "; cin >> b; fflush(stdin);
		cout << "Nhap vao giay = "; cin >> a; fflush(stdin);
		if (a  <0 || a>60 || a<0 || b <0 || b> 60 || c<0 || c>23) cout << "Khong hop le ! Nhap lai !  ";
	} while (a  <0 || a>60 || a<0 || b <0 || b> 60 || c<0 || c>23);
	h = c; phut = b; giay = a;
}
void time::advanced(int h_1, int m_1, int s_1)
{
	cout << "Nhap vao h , phut , giay muon tang \n";
	do{
		cout << "Nhap vao h = "; cin >> h_1; fflush(stdin);
		cout << "Nhap vau phut = "; cin >> m_1; fflush(stdin);
		cout << "Nhap vao giay = "; cin >> s_1; fflush(stdin);
		if (a  <0 || a>60 || a<0 || b <0 || b> 60 || c<0 || c>23) cout << "Khong hop le ! Nhap lai !  ";
	} while (a  <0 || a>60 || a<0 || b <0 || b> 60 || c<0 || c>23);
	a = (a + s_1); giay = a % 60;
	b = (b + m_1 + a / 60); phut = b % 60;
	c = (c + h_1 + b / 60); h = c % 24;
}
void time::printf()
{
	//setfill('0');
	//cout<<setw(2)<<h<<"h:"<<setw(2)<<phut<<"':"<<setw(2)<<giay<<"s"<<endl;
	cout << h << "h:" << phut << "':" << giay << "s" << endl;
}
void time::reset(int a, int b, int c)
{
	h = a; phut = b; giay = c;
}
int main()
{
	int h_1 = 0, m_1 = 0, s_1 = 0;
	time T;
	T.normalize();
	T.printf();
	cout << "=========================================" << endl;
	T.advanced(h_1, m_1, s_1);
	cout << "Thoi gian sau khi tang  : \n";
	T.printf();
	cout << "=================================================\nReset Time (Y Or N )?" << endl;
	char X;
	cin.get(X);
	if (X == 'Y' || X == 'y') { cout << "Reset time :"; T.reset(0, 0, 0); T.printf(); }
	system("pause");
	return 0;
}