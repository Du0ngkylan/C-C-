#include<stdio.h>
#include<conio.h>
#include<string.h>

typedef struct
{
	char Hoten[20];
	float Diem;
	char Loai[10];
}HoSo;

void In(HoSo hs)
{
	printf("|%20s|%6.2f|%20s|\n",hs.Hoten,hs.Diem,hs.Loai);
}

int main()
{
	HoSo a[50];
	int nCnt;
	printf("Nhap so SV: ");
	scanf("%d", &nCnt);

	for (int i = 0; i < nCnt; i++)
	{

		printf("\nNhap sv thu %d: ", i + 1);
		//printf("\nNhap HoTen: ");
		gets(a[i].Hoten);
		printf("\nNhap Diem: ");
		scanf("%f", &a[i].Diem);
		fflush(stdin);
		
	}
	printf("|-------------------------Xep Loai-----------------------|\n");
	printf("|---------HoTen--------|-----Diem----|--------XepLoai---------|\n");
	printf("|---------------------------------------------------------|\n");
	
	for (int i = 0; i < nCnt;i++)
	{
		if (a[i].Diem < 5)
		{
			strcpy(a[i].Loai, "Khong Dat");
		}
		else if (a[i].Diem < 7)
		{
			strcpy(a[i].Loai, "TrungBinh");
		}
		else if (a[i].Diem < 8)
		{
			strcpy(a[i].Loai, "Kha");
		}
		else
		{
			strcpy(a[i].Loai, "Gioi");
		}
		In(a[i]);
	}


	_getch();
	return 0;
}