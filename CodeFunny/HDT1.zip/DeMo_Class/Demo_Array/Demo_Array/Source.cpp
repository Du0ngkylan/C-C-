#include<iostream>
#include<array>
#include<algorithm>
#include<iterator>

using namespace std;
int main()
{
	array<int, 10> Arr = {1,9,3,7,0,6,22,15,12,14};

	//Arr.assign(10);
	cout << Arr.at(1) << endl;

	sort(Arr.begin(),Arr.end());



	int nMax = *max_element(Arr.begin(), Arr.end());

	cout << "Max = " << nMax << endl;

	for (int & it : Arr)
	{
		cout << it << " ";
	}

	system("pause");
	return 0;
}