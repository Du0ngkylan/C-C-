#include<iostream>
#include<list>
#include<algorithm>

using namespace std;

int main()

{
	list<int> myInt;

	for (int i = 0; i <= 5; i++)
	{
		myInt.push_back(i);
	}



	for (list<int>::const_iterator x = myInt.begin(); x != myInt.end();)
	{
		cout << (*x)<<endl;
		
		if (*x == 3)
		{
			x = myInt.erase(x);
		}
		else
		{
			x++;
		}
	}

	for (list<int>::const_iterator x = myInt.begin(); x != myInt.end(); x++)
	{
		cout <<"--------"<< (*x) << "\t";
	}

	system("pause");
	return 0;
}