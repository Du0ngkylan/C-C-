#include<stdio.h>
#include<conio.h>

void nhapmang(int a[50], int n)
{
	for (int i = 0; i<n; i++)
	{
		printf("a[%d]", i);
		scanf("%d", &a[i]);
	}
}

bool kt(int a[50],int x)
{	
	for (int i = 0; i < x; i++)
	{
		if (a[i] == a[x])
		{
			return false;
		}
	}

	return true;
}

void timsolanxuathien(int a[50], int n)
{
	int dem;
	for (int i = 0; i<n; i++)
	{
		dem = 1;
		if (!kt(a, i))
		{
			continue;
		}

		for (int j = i + 1; j<n; j++)
		{
			if (a[i] == a[j])
			{
				dem++;
			}
		}
		printf("so lan xuat hien cua %d la %d \n", a[i], dem);
	}
}
int main()
{

	int a[50], n;
	printf("nhap gia tri cua n la ");
	scanf("%d", &n);
	nhapmang(a, n);
	timsolanxuathien(a, n);

	_getch();
	return 0;
}