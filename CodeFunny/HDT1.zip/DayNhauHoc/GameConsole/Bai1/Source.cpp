﻿#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<Windows.h>
#include"console.h"

#define consoleWidth 85
#define consoleHeight 25

enum TrangThai{
	UP,
	DOWN,
	RIGHT,
	LEFT
};

struct ChayChu{
	int x, y;// tọa độ x,y
	char s[32];
	TrangThai tt;
};


int main(){
	ChayChu A;

	strcpy_s(A.s, "XIN CHAO CAC BAN");
	A.y = 0;
	A.x = ((consoleWidth - strlen(A.s))/2);

	A.tt = DOWN;



	while (1){
		clrscr();
		gotoXY(A.x, A.y);
		printf_s("%s", A.s);

		// Xử lý chạm biên
		if (A.y == consoleHeight - 1)
			A.tt = UP;
		else if (A.y == 0)
			A.tt = DOWN;

		if (A.tt == DOWN)
			A.y++;
		else if (A.tt == UP)
			A.y--;

		Sleep(200);
	}

	
	_getch();
	return 0;
}