#ifndef FUNCTION_NUMBER_H_INCLUDED
#define FUNCTION_NUMBER_H_INCLUDED

int checkSoNguyenTo(int n);
int checkSoChinhPhuong(int n);
int checkSoHoanThien(int n);
void MaxSoNguyen(int n);
void MinSoNguyen(int n);



#endif // FUNCTION_NUMBER_H_INCLUDED