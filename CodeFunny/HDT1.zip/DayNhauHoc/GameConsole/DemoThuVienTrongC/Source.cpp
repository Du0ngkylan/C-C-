#include<stdio.h>
#include<conio.h>
#include"Function_Number.h"


int main(){
	int n;
	printf_s("\nNhap n = ");
	scanf_s("%d", &n);

	_getch();
	return 0;
}