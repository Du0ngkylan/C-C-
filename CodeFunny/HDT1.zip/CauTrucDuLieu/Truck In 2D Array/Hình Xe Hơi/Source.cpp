#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
	int i, j, t;
	float s = 0, a, b;
	_getch();
	for (t = -72; t<62; ++t)
	{
		//system("cls");
		for (i = 0; i<15; ++i)
		{
			cout << endl;
		}
		for (i = 0; i<17; ++i)
		{
			for (j = 0; j<78; ++j)
			{
				if (((j + t == 20 || j + t == 59) && i != 0) || (i == 0 && j + t<59 && j + t>20) || (i == 5 && j + t<20 && j + t>14) || (j + t == 20 - i&&i >= 5 && i <= 10) || (i>10 && j + t == 10) || (i == 16 && j + t>10 && j + t<60) || (i == 10 && j + t<20 && j + t>10) || (i == 15 && j + t<60 && j + t>20) || (j + t == 15 && i<10 && i>5) || (i == 12 && j + t>11 && j + t<15) || (i == 13 && (j + t == 12 || j + t == 13)))
					cout << "*";
				else
					cout << " ";
			}
			cout << endl;
		}
		for (i = 0; i<4; ++i)
		{
			for (j = 0; j<78; ++j)
			{
				if (((i == 0 || i == 3) && (j + t == 15 || j + t == 16 || j + t == 54 || j + t == 55 || j + t == 49 || j + t == 50 || j + t == 44 || j + t == 45)) || ((i == 2 || i == 1) && ((j + t>13 && j + t<18) || (j + t>52 && j + t<57) || (j + t>47 && j + t<52) || (j + t>42 && j + t<47))))
					cout << "*";
				else
					cout << " ";
			}
			cout << endl;
		}
		for (j = 0; j<80; ++j)
			cout << "*";
		for (a = 0; a<10000; ++a)
		{
			s = s + a;
			for (b = 0; b<1000; ++b)
				s = s + b;
		}

	}
	_getch();
}