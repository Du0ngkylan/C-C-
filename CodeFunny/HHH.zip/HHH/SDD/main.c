#include <stdio.h>
#include <stdlib.h>

int val[23] = {0};
int min_step = 999999999, source, target, k1, k2, n;

int first_diff_bit(int n, int m)
{
    int diff = n ^ m;
    int ret = 0;
    while (diff % 2 == 0)
    {
        ret++;
        diff /= 2;
    }
    return ret;
}

void find(int curr_num, int curr_step)
{
    if (curr_num == target)
    {
        if (curr_step < min_step)
            min_step = curr_step;
        return;
    }
    if (curr_step >= min_step)
        return;
    int i, k;
    i = first_diff_bit(curr_num, target);
    for (k = k1; k <= k2; k++)
    {
        if (i + k > n)
            break;
        int next_num = curr_num ^ (val[k] << i); // dao k bit tu vi tri i cua curr_num
        find(next_num, curr_step + 1);
    }
}

int main()
{
    // Khoi tao mang de dao bit
    int i;
    for (i = 1; i < 23; i++)
        val[i] = (val[i - 1] << 1) + 1;

    // Tinh toan va gan cac gia tri
    // Chuyen doi tu chuoi bit thanh cac so tuong ung
    k1 = 2;
    k2 = 3;
    n = 5;
    source = 8; // 01000
    target = 3; // 00011

    // Tim kiem
    find(source, 0);

    if (min_step == 999999999)
        printf("Khong the bien doi");
    else
        printf("So buoc bien doi: %d", min_step);
    return 0;
}
