#include "FoamMesh.h"

FoamMesh::FoamMesh()
{
    //ctor
}

FoamMesh::~FoamMesh()
{
    //dtor
}
