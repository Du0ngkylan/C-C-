#ifndef FOAMMESH_H
#define FOAMMESH_H


class FoamMesh
{
    public:
        FoamMesh();
        virtual ~FoamMesh();

    protected:

    private:
};

#endif // FOAMMESH_H
