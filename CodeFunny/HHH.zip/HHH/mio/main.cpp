#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;

    char myName[10] = "mai duong";
    char *p = myName;
    cout << "hello: " << p << endl;


    char *zzz = "abcd";
    cout << zzz << endl;

    int foo[20];
    foo[0] = 1;
    foo[1] = 2;


    int *ppp = foo;
    cout << ppp << endl;
    return 0;
}
