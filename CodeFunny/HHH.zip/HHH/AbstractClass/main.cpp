#include <iostream>
/*
- Lớp được gọi là Abstract Class nếu nó chứa ít nhất 1 hàm thuần ảo (pure virtual function).
- Không thể tạo đối tượng với lớp Abstract.
- Nếu chúng ta không override hàm thuần ảo trong lớp derived thì lớp derived cũng trở thành abstract class.
- Abstract class có thể chứa constructors
*/
using namespace std;

// An abstract class with constructor
class Base
{
protected:
   int x;
public:
  virtual void fun() = 0;
  Base(int i) { x = i; }
};

class Derived: public Base
{
    int y;
public:
    Derived(int i, int j):Base(i) { y = j; }
    void fun()
    {
         cout << "x = " << x << ", y = " << y;
    }
};



class shape   // An interface class
{
  public:
    virtual ~shape();
    virtual void move_x(int x) = 0;
    virtual void move_y(int y) = 0;
    virtual void draw() = 0;
//...
};

int main(void)
{
//    Derived d(4, 5);
//    d.fun();

    Base *bp = new Derived(4, 5);
    bp->fun();
    return 0;
}
