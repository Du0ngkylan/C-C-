#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

#define MAX 100

int Menu(); // Menu Chinh
void QuanLyDoiBong();
int MenuQLDB();
void DanhSachDB();
void CapNhatThongTinDB();
void ThemMoiDB();



int main()
{
    int nChoose, check = 0;
    do{
        nChoose = Menu();
        switch(nChoose)
        {
        case 1:
            QuanLyDoiBong();
            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            break;
        case 0:
            check = 1;
            break;
        }
    }while(!check);




    return 0;
}




int Menu()
{
    char c;
    system ("cls");
    printf("--- Chao mung den voi V-League 2018 ---\n");
    printf("1.Quan Ly Danh Sach Doi Bong\n");
    printf("2.Quan Ly Lich Thi Dau\n");
    printf("3.Quan Ly Ket Qua Thi Dau\n");
    printf("4.Thong Ke\n");
    printf("0.Thoat\n");
    printf("\n\n");
    fflush(stdin);
    do {
        c = getch();
    }while (c < '0' || c > '4');
    return c - '0';
}

void QuanLyDoiBong()
{
    int nChoose,check = 0;
    do{
        nChoose = MenuQLDB();
        switch(nChoose)
        {
            case 1 :
                DanhSachDB();
                break;
            case 2 :
                CapNhatThongTinDB();
                break;
            case 3 :
                ThemMoiDB();
                break;
            case 0 :
                check = 1;
                break;
        }
    } while (!check);
}

int MenuQLDB()
{
    char c;
    system ("cls");
    printf("Quan Ly Danh Sach Doi Bong\n");
    printf("1.Xem Danh Sach Doi Bong\n");
    printf("2.Sua Thong Tin Doi Bong\n");
    printf("3.Them Moi Doi Bong\n");
    printf("0.Tro Ve Menu Chinh\n");
    printf("\n\n");
    fflush(stdin);
    do {
        c = getch();
    }while (c < '0' || c > '3');
    return c - '0';
}

void DanhSachDB()
{

}

void CapNhatThongTinDB()
{

}

void ThemMoiDB()
{

}
