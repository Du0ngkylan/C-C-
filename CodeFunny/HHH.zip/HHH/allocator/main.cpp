#include <iostream>
#include <memory>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    allocator<char> Storage;

    cout << Storage.max_size() << endl;

    return 0;
}
