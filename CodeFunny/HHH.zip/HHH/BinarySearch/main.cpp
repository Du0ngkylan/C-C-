#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

void randomArr(int arr[])
{
    int nLen = 10;
    for(int i = 0; i < nLen; i++)
    {
        arr[i] = 1 + rand() % 20;
    }
}

void printArr(int arr[])
{
    int nLen = 10;
    for(int i = 0; i < nLen; i++)
    {
        cout << "   " << arr[i];
    }
}

bool binarySearch(int arr[], int sizeArr,int x)
{
    int left = 0;
    int right = sizeArr - 1;
    while(left <= right)
    {
        int mid = left + ((right - left)/2);
        if(arr[mid] == x)
        {
            return true;
        }
        else if(x < arr[mid])
        {
            right = mid - 1;
        }
        else
        {
            left = mid + 1;
        }
    }
    return false;
}

int main()
{
    int nArr[11] = {2, 5, 6, 8, 10, 13, 16, 18, 23, 32, 44};
//    srand((unsigned)time(NULL));
//    randomArr(nArr);
    printArr(nArr);
    if(binarySearch(nArr, 11, 22))
    {
        cout << "\nfind" <<endl;
    }
    else
    {
        cout <<"\nNot find"<<endl;
    }

    return 0;
}
