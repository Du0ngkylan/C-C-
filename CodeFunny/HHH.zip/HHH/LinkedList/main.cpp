#include <iostream>
#include <cstdlib>
using namespace std;

//1. Khai báo CTDL- Danh sách Liên Kết Đơn
struct Node
{
    int Data;
    Node *pNext;
};
typedef struct Node NODE;

struct List
{
    NODE *pHead;
    NODE *pTail;
};

typedef struct List LIST;

//2. Khởi Tạo DSLK Đơn
void Init(LIST &L)
{
    L.pHead = L.pTail = NULL;
}

//3. Tạo Node Trong Danh Sách
NODE *GetNode(int x) // x là dữ liệu đưa vào Data
{
    // Cấp phát 1 Node
    NODE *p = (NODE *)malloc(sizeof (NODE)); //Cap phat vung nho cho P
    // NODE *p = new NODE;

    if(p == NULL)
    {
        return NULL;
    }
    p->Data = x;
    p->pNext = NULL;
    return p;
}
//4. Thêm Node (Vào Đầu Hoặc Cuối)

void AddHead(LIST &l, NODE *p)
{
    if(l.pHead == NULL)
    {
        l.pHead = l.pTail = p;
    }
    else
    {
        p->pNext = l.pHead;
        l.pHead = p;
    }
}

void AddTail(LIST &l, NODE *p)
{
    if(l.pHead == NULL)
    {
        l.pHead = l.pTail = p;
    }
    else
    {
        l.pTail->pNext = p;
        l.pTail = p;
    }
}

void InputList(LIST &l)
{
    int n;
    cout << "\nNhap So Node: ";
    cin>>n;

    Init(l);
    for(int i = 1; i <= n; i++)
    {
        int x;
        cout<< "\nNhap Vao Data: ";
        cin >> x;

        NODE *p = GetNode(x);
        AddTail(l, p);
    }
}

void OutPutList(LIST l)
{
    for(NODE *p = l.pHead; p != NULL; p = p->pNext)
    {
        cout << "   " << p->Data;
    }
}

int main()
{
    cout << "Hello world!" << endl;
    LIST l;
    InputList(l);
    OutPutList(l);
    return 0;
}
