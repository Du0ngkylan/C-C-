#include <iostream>

using namespace std;

int main()
{
    char s[] = "vncoding forum";
    char *p = s;
    cout << *p <<endl;

//    int a[4] = {3, 5, 1, 8};
//    int *p = a;
//    cout << *p << endl;

    return 0;
}
