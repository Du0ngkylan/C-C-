#include <iostream>
#include <string>

using namespace std;

void BBSort(int a[], int n)
{
    bool isSorted = false;
    while(!isSorted)
    {
        isSorted = true;
        for(int i = 0; i < n - 1; i++)
        {
            if(a[i] > a[i+1])
            {
                swap(a[i], a[i+1]);
                isSorted = false;
            }
        }
        n--;
    }
}

void BB1(int a[], int n)
{
    for(int i = 0; i < n -1; i++)
    {
        for(int j = n-1; j > i; j--)
        {
            if(a[j] > a[j-1])
            {
                swap(a[j], a[j-1]);
            }
        }
    }
}

void OutPut(int a[], int n)
{
    for(int i = 0; i < n; i++)
    {
        cout << "   " << a[i];
    }
}

class ABase{
        int iMem;
};

class BBase : public ABase {
        int iMem;
};

class CBase : public ABase {
        int iMem;
};

class ABCDerived : public BBase, public CBase {
        int iMem;
};

class A
{
//    char a;
//public:
//    ~A();
};

class CCC:public A
{
    int kkk;
};

int main()
{

//    int a[10] = {2,5,1,9,2,6,8,7,12,4};
//    OutPut(a,10);
//    BB1(a,10);
//    cout<< "\n";
//    OutPut(a,10);
//    cout << sizeof(A) << endl;
//    cout << sizeof(CCC) << endl;
//    cout << sizeof(ABase) << endl;
//    cout << sizeof(BBase) << endl;
//    cout << sizeof(CBase) << endl;
//    cout << sizeof(ABCDerived) << endl;

    char akkk;
    cout << sizeof(1) <<endl;
    return 0;
}
