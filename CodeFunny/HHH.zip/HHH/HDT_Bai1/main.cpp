#include <iostream>
#include <conio.h>
#include <cstdio>
#include <string>
using namespace std;


class Person
{
public:
    string HoTen;
    string NgaySinh;
    string QueQuan;
};

class KySu: public Person
{
public:
    string NganhHoc;
    int NamTotNghiep;
    void Nhap();
    void Xuat();

};

void KySu::Nhap()
{
    cin.ignore();
    cout << "Ho ten: "; getline(cin, HoTen);
    cout << "Ngay sinh: "; getline(cin, NgaySinh);
    cout << "Que quan: "; getline(cin, QueQuan);
    cout << "Nganh hoc: "; getline(cin, NganhHoc);
    cout << "Nam tot nghiep: "; cin >> NamTotNghiep;
}

void KySu::Xuat()
{
    cout << "Ho ten: " << HoTen << endl;
    cout << "Ngay sinh: " << NgaySinh << endl;
    cout << "Que quan: " << QueQuan << endl;
    cout << "Nganh hoc: " << NganhHoc << endl;
    cout << "Nam tot nghiep: " << NamTotNghiep << endl;

}


int main()
{
    int i,n;
    KySu a[100];
    cout << "n= ";
    cin >> n;

    for(i = 0; i < n; i++)
    {
        cout << "Ky su thu " << (i+1) << ":" << endl;
        a[i].Nhap();
    }

    cout << "Thong tin vua nhap:" << endl;
    for(i = 0; i < n; i++)
        a[i].Xuat();

//    int Max=a[0].NTN;
//    for(i=0;i<n;i++)
//        if(a[i].NTN>Max)
//            Max=a[i].NTN;
//            cout<<"Ky su co nam tot nghiep gan day nhat la: \n";
//
//    for(i=0;i<n;i++)
//        if(a[i].NTN==Max)
//            a[i].Xuat();

    return 0;
}
