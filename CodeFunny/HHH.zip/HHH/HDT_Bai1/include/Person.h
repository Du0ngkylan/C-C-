#ifndef PERSON_H
#define PERSON_H


class Person
{
    public:
        Person();
        virtual ~Person();

    protected:

    private:
};

#endif // PERSON_H
