#include <iostream>
#include <vector>

using namespace std;

int main(int argc, char* argv[])
{
    cout << "Hello world!" << endl;
    vector<string> parameters(argv, argv + argc);
    return 0;
}
