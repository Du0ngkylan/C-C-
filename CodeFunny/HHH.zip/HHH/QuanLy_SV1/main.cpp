#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;


class HocSinh
{
public:

//private:
	string hoten, diachi, masv;
	float toan;
	float van;
	float dtb;
//public:
    HocSinh()
    {
        hoten = "";
        diachi = "";
        masv = "";
        toan = 0;
        van = 0;
        dtb = 0;
    }
	void Nhap();
	void Xuat();
	float TinhDiemTrungBinh();
	void XepLoai();
//    string getHoTen();
//    string setHoTen();
//    string getDiaChi();
//    string setDiaChi();
//    string getMaSV;
//    string setMaSV;
//    float getToan();
//    float setToan();
//    float getVan();
//    float setVan();
//    float getDTB();
//    float setDTB();

};

class QuanLyHocSinh
{
public:

//private:
    vector<HocSinh> vHS;

//public:
    void Nhap();
    void Xuat();
    void SapXep();

};

void QuanLyHocSinh::SapXep()
{
    sort( vHS.begin( ), vHS.end( ), [ ]( const HocSinh& hs1, const HocSinh& hs2 )
    {
        return hs1.dtb < hs2.dtb;
    });
}

void QuanLyHocSinh::Nhap()
{
    int n;
	cout << " Nhap so luong hoc sinh: ";
	cin >> n;
	vHS.resize(n);
    for (int i = 0; i < n; i++)
	{
		vHS[i].Nhap();
	}

}

void QuanLyHocSinh::Xuat()
{
    cout << "Thong Tin Sinh Vien: \n";
    for (size_t i = 0; i < vHS.size(); i++)
	{
		vHS[i].Xuat();
	}
}

void HocSinh::Nhap()
{
	cin.ignore();
	cout << "Nhap ho ten hoc sinh: ";
	getline(cin, hoten);
	cout << "Nhap mssv: ";
	getline(cin, masv);
	cout << "Nhap dia chi:";
	getline(cin, diachi);
	cout << "Nhap diem toan: ";
	cin >> toan;
	cout << "Nhap diem van: ";
	cin >> van;

}

void HocSinh::Xuat()
{
	cout << " Ho ten :" << hoten << endl;
	cout << " Ma so :" << masv << endl;
	cout << " Dia chi : " << diachi << endl;
	cout << " Diem Toan: " << toan << endl;
	cout << " Diem Van: " << van << endl;
	cout << " Diemtrungbinh: " << TinhDiemTrungBinh() << endl;
	XepLoai();
}

void HocSinh::XepLoai()
{
	if (dtb >= 9.0)
        cout << "Xep Loai : Xuat Sac\n";
	else if (dtb >= 8.0 && dtb < 9.0)
		cout << "Xep loai : Gioi\n";
	else if (dtb >= 7.0 && dtb < 8.0)
        cout << "Xep Loai : Kha\n";
	else if (dtb >= 6.0 &&dtb < 7.0)
        cout << "Xep Loai :Trung Binh Kha\n";
	else if (dtb >= 5.0 &&dtb < 6.0)
        cout << "Xep Loai :Trung binh\n";
	else if (dtb >= 3.0 &&dtb < 5.0)
        cout << "Xep Loai : Yeu\n";
	else if (dtb < 3.0)
        cout << "Xep Loai :Yeu\n";

}

float HocSinh::TinhDiemTrungBinh()
{
    dtb = (float)(toan + van) / 2;
    return dtb;
}

int main()
{
    QuanLyHocSinh *qlHS = new QuanLyHocSinh();
    qlHS->Nhap();
    qlHS->Xuat();
    qlHS->SapXep();
    qlHS->Xuat();

    if(qlHS != NULL)
    {
        delete qlHS;
    }

    return 0;
}
