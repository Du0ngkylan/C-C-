/* Bai toan thap HN */
#include<stdio.h>
#include<conio.h>

void ThapHaNoi(int n, int A, int B,int C)
{
 if(n==1) printf("Di chuyen dia tren cung tu %d den %d"\n, A, C); //m sua them chu vao nhe!
 else
	  {
	      ThapHaNoi(n-1, A, B, C);
          ThaphaNoi(1, A, B, C);
	      ThapHaNoi(n-1, B, A, C);
       }
}

void main()
  {
	int n, A=1, B=2, C=3;
	printf("So dia can chuyen:");
    scanf("%d",&n);
	ThapHaNoi(n, A, B, C);
	getch();
  }
