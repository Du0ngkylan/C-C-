#include<stdio.h>
#include<conio.h>

int f(int a) 
{
    if(n<=2)
    return 1;
    else
    return (f(n-1)+f(n-2));
}

void main()
{
     int i,n;
     clrscr();
     printf("Nhap vao gia tri cho n : ");
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     printf("%d ",f(i));
     getch();
}
