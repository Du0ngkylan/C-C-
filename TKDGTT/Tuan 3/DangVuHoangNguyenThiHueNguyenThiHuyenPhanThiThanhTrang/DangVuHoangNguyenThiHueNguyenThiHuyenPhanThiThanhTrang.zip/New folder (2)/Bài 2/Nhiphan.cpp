//In bieu dien nhi phan cua so nguyen
#include <stdio.h>
#include <conio.h>
void NhiPhan (int n)
{
         if (n<0)
         {
                 print ("Khong bieu dien duoc nhi phan cua so am");
                 return;
         }
         if (n/2>0) 
         NhiPhan(n/2):
         printf("%d", n%2);
}
void main()
{
     int n;
     printf("Nhap so nguyen n:");
     scanf("%d",&n);
     NhiPhan(n);
     getch();
}
