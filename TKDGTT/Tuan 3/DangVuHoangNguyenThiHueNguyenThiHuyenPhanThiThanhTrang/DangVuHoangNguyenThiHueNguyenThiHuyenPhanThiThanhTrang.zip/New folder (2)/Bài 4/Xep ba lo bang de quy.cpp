#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<string.h>
#define MAX 100
#define max 30
int n,W,k;
int Tongtrongluong=0;float Tonggiatri=0;float Giatamthoi;
int x[MAX],xtemp[MAX];
int ttl[MAX],gtc[MAX];
typedef struct
{
        char Ten[20];
        int Trong_luong,Gia_tri,So_luong;
        float Don_gia;
}
      Do_vat;

Do_vat Ds_vat[MAX];
void Nhap()
{
        printf("\n Nhap vao so luong cua do vat n= ");
		scanf("%d",&n);
		printf("\n Nhap vao Trong luong cua balo W= ");
		scanf("%d",&W);
		for(int i=1;i<=n;i++)
        {
			printf("\n ten do vat thu %d: ",i);
			scanf("%s",&(Ds_vat[i-1].Ten));
			printf("\n so luong: ");
			scanf("%d",&(Ds_vat[i-1].So_luong));
			printf("\n trong luong: ");
			scanf("%d",&(Ds_vat[i-1].Trong_luong));
			printf("\n gia tri:  ");
			scanf("%d",&(Ds_vat[i-1].Gia_tri));
			Ds_vat[i-1].Don_gia=float(Ds_vat[i-1].Gia_tri)/float(Ds_vat[i-1].Trong_luong);
			printf("\n don gia: %f",Ds_vat[i-1].Don_gia);
	    }
		  
}

//Chuong trinh lay du lieu tu file:
int Lay_dulieu(char *duongdan)
{
    FILE *f;f=fopen(duongdan,"r+");
    if(f==NULL) {printf("\n\tLOI: khong tim duoc file\n");return 1;}
    else
    {   
        char s[100];
        fgets(s,100,f);
        fscanf(f,"%d",&W);printf("Trong luong toi da cua ba lo la W=%d",W);
		while(!feof(f)&&k<=maxk-1)
        {
				fscanf(f,"%s%d%d%d",&(Ds_vat[k].Ten),&(Ds_vat[k].So_luong),&(Ds_vat[k].Trong_luong),&(Ds_vat[k].Gia_tri));
				if(Ds_vat[k].Trong_luong)
                {
					Ds_vat[k].Don_gia=float(Ds_vat[k].Gia_tri)/float(Ds_vat[k].Trong_luong);
					printf("\n\n\tDo Vat %s co so luong: %d, trong luong: %d, gia tri: %d, don gia: %f",Ds_vat[k].Ten,Ds_vat[k].So_luong,Ds_vat[k].Trong_luong,Ds_vat[k].Gia_tri,Ds_vat[k].Don_gia);
				    k++; 
                }
	    }
		if(k==maxk) printf("\n\tChi lay %d do vat",k);
		printf("\nk=%d",k);
		n=k;
		flushall();
		fclose(f);
		return 0;
      }

}

void Sap_xep()
{
		Do_vat temp;
		for(int i=0;i<n-1;i++)
			Ds_vat[i].Don_gia=float(Ds_vat[i].Gia_tri)/float(Ds_vat[i].Trong_luong);
		for(i=0;i<n;i++)
			for (int j=i+1;j<n ;j++)
		{
				if(Ds_vat[i].Don_gia<Ds_vat[j].Don_gia)
				{ temp=Ds_vat[i];
				  Ds_vat[i]=Ds_vat[j];
				  Ds_vat[j]=temp;
				}
	     }
		printf("\n Sau khi sap xep theo thu tu giam dan cua don gia\n");
		for(i=0;i<n;i++)
			printf("\n Do vat %s co so luong: %d, trong luong: %d, gia tri %d, don gia: %.2f\n",Ds_vat[i].Ten,Ds_vat[i].So_luong,Ds_vat[i].Trong_luong,Ds_vat[i].Gia_tri,Ds_vat[i].Don_gia);
		Ds_vat[n].Gia_tri=0;
		for (int l=0;l<n ;l++ )
		{
			xtemp[l]=0;
		}
}
void Quay_lui(int *b)
{
	if(Tonggiatri>Giatamthoi)
	 {
		Giatamthoi=Tonggiatri;
		for(int i=0;i<n;i++)
		 {
		    x[i]=b[i];
		 }
	 }
}
	
void Phan_nhanh(int i)
{
	int t,a;
	if (i==0)
	{
		a=W/Ds_vat[i].Trong_luong;
	}
	else
		a=(W-ttl[i-1])/Ds_vat[i].Trong_luong;

	if(a>Ds_vat[i].So_luong) 
		t=Ds_vat[i].So_luong;
	else t=a;
	for(int j=t;j>=0;j--)
		{	
			xtemp[i]=j;
			if(i==0)
			{		
					ttl[i]=Ds_vat[i].Trong_luong*xtemp[i];
					gtc[i]=xtemp[i]*Ds_vat[i].Gia_tri;
					Giatamthoi=gtc[i]+(W-ttl[i])*Ds_vat[i+1].Gia_tri;
			}
			else
			{
					ttl[i]=ttl[i-1]+Ds_vat[i].Trong_luong*xtemp[i];
					gtc[i]=gtc[i-1]+xtemp[i]*Ds_vat[i].Gia_tri;
					Giatamthoi=gtc[i]+(W-ttl[i])*Ds_vat[i+1].Gia_tri;
			}
			if(i==n-1)
			{	if(Tonggiatri<=Giatamthoi)
					Tonggiatri=Giatamthoi;
				goto finish;
			}
			if (Giatamthoi>Tonggiatri)
			{
				x[i]=xtemp[i];
				
				Phan_nhanh(i+1);
			}
			
		}
}
void Ket_qua()
{
	printf("\n Tong gia tri do vat %8.2f",Tonggiatri);
	printf("\n phuong an toi uu:");
	for(int i=0;i<n;i++)
	 {
	    printf("%d %s  ",x[i],Ds_vat[i].Ten);
	 }
     }
void main()
{
        clrscr();
		printf("\n\n Ket qua:\n\n\n");
		char *pa ="F:\\test.txt";
		Lay_dulieu(pa);
		Sap_xep();
        Phan_nhanh(0);
		Ket_qua();
		getch();
		return;
}
