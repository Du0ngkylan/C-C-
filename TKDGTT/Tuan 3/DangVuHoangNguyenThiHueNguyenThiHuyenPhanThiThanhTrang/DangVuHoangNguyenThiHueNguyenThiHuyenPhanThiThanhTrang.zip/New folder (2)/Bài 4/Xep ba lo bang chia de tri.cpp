/*N do vat.
    Moi do vat co trong luong P va gia tri V.
    Ba lo co gioi han trong luong W.
    Chon cac do vat xep vao ba lo <= W va gia tri max.    
    Moi do vat chi duoc chon toi da 1 lan.
    -Phan tich bai toan: Ta can nhung do vat co gia tri cao
    ma trong luong lai nho de sao cho co the mang duoc nhieu
    do quy. Ta se quan tam den don gia cua tung loai do vat.
    Don gia cang cao thi do cang quy.
    -Thuat toan
        + Tinh gia tri cua tung do vat
        + Xet cac loai do vat theo gia tri tu lon den nho
        + Voi moi loai do vat duoc xet se lay 1 so luong toi da
        ma trong luong con lai ba lo cho phep.
        + Xac dinh trong luong con lai cua Ba lo va quay lai
        buoc 3 cho den khi khong chon duoc do vat nua.
*/
#include<stdio.h>
#include<conio.h>
int w[100], v[100], m, chiso[100], danhdau[100],n;
struct DoVat
{
     char Ten [20];
     float TrongLuong, GiaTri, DonGia;
     int PhuongAn;//so luong do vat chon
};
void TinhDonGia(DoVat sp[], int n)
{
   for(int i = 1; i <= n; i++)
      sp[i].DonGia = sp[i].GiaTri / sp[i].TrongLuong;
}
//Do phuc tap O(n)
void SapXep(DoVat sp[], int n)

{

   for(int i = 1; i <= n - 1; i++)

      for(int j = i + 1; j <= n; j++)

        if (sp[i].DonGia < sp[j].DonGia)

           swap(sp[i], sp[j]);

}
//Do phuc tap )(n2)
void Sanpham(DoVat sp[], int n, float W)

{

     for (int i = 0; i < n; i++) 
     {

           sp[i].PhuongAn = W / sp[i].TrongLuong;

           W -= sp[i].PhuongAn * sp[i].TrongLuong;             

     }

}
//Do phuc tap O(n)
int main()
{
    DoVat();
    Sanpham();
    getch();
    return 0;   
}
