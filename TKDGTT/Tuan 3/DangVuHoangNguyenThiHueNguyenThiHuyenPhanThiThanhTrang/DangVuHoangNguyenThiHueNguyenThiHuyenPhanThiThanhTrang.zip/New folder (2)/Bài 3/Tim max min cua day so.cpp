#include <stdio.h>
#include <conio.h>
int A[10]={1,20,50,7,9,2,10,4,34,3};
int max(int a,int b)
{
    if (a>=b) return a;
    return b;
}
int min(int a,int b)
{
    if (a<=b) return a;
    return b;
}
void maxmin(int A[10], int L, int R, int &Max, int &Min)
{
     int Max1, Min1, Max2, Min2;
     if ((L+1)<R)
     {
                 maxmin(A,L,((R+L)/2),Max1,Min1);
                 maxmin(A,(((R+L)/2) + 1),R, Max2,Min2);
                 Max=max(Max1,Max2);
                 Min=min(Min1,Min2);
     }
     else
     {
                 if (A[L]<=A[R]) 
                 {
                                 Max=A[R];
                                 Min=A[L];
                 }
                 else
                 {
                                 Max=A[L];
                                 Min=A[R];
                 }
     }
}
void main()
{
     int Max,Min;
     maxmin(A,0,9,Max,Min);
     printf("\nphan tu nho nhat cua day la : %d",Min);
     printf("\nphan tu lon nhat trong day la : %d",Max);
     getch();
}
