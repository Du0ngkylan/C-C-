//Tim kiem phan tu tren mang da sap xep
#include <stdio.h>
#include <conio.h>
const max= 20;
int Timkiem(int a[max],int x,int l,int r)
{
                int mid;
                if(l>r) return 0;
                mid=(l+r)/2;
                if(x==a[mid]) 
                return mid;
                if(x>a[mid]) 
                return Timkiem(a,x,mid+1,r);
          return Timkiem(a,x,l,mid-1);
}
void main()
{
     int A[]={1,4,7,12,16,20,22,27,31,35};
     clrscr();
     printf("%d",Timkiem(A,12,0,9));
     getch();
}
