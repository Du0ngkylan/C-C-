/*cho 1 do thi G vo huong, lien thong gom n dinh(n<=100)
tim cay bao trum nho nhat cua G */

#include<conio.h>
#include<stdio.h>
#include<iostream.h>

int n;//so dinh cua do thi
int a[50][50];// ma tran trong so
int t[50]; //dung de danh dau dinh nao da chon
int dau[50],cuoi[50];//dinh dau va cuoi cua canh trong cay bao trum
int gan[50];//xac dinh dinh gan voi dinh vua duoc chon
int d[50];//khoang cach tu dinh con lai den dinh da xet

void Nhap()
{
	cout<<"Nhap so dinh n=";cin>>n;
	//nhap trong so duong di tu i den j
	//vocung=32000
	cout<<"\nNhap trong so cua cung (i,j) tuong ung a[i][j]";
	cout<<"\n(khong co duong di nhap =3000)"<<"\n";
	for(int i=0;i<n-1;i++)
	for(int j=i+1;j<n;j++)
	{ 
	    cout<<"  a["<<i<<"]["<<j<<"]=";
		cin>>a[i][j];
		a[j][i]=a[i][j];
	}
	for(int i=0;i<n-1;i++)
	    a[i][i]=0;
}

void KhoiTao()
{
	for(int i=0;i<=n-1;i++)
        d[i]=a[0][i];//khoang cach tu  dinh 0 den cac dinh con lai
}

void In()
{
	for(int i=0;i<=n-1;i++)
	{
	    for(int j=0;j<=n-1;j++)
	    cout<<"  "<<a[i][j]<<"     ";
	    cout<<"\n";
	}
}

// Cac thu tuc chinh cua thuat toan
int BestSelect()
{
	int Imin=0;
	int Dmin=32000;
	for(int i=0;i<=n-1;i++)
	//neu dinh i chua chon va k/c cua no nho hon Dmin thi chon
	if(!t[i]&&Dmin>=d[i])
	{
	    Dmin=d[i];
	    Imin=i;
	}
	return Imin;
	//tra ve dinh co khoang cach ngan nhat voi tap dinh da lay
}

void Prim()//ap dung phuong phap tham lam
{ 
	int chon=0;//dinh vua duoc ket nap
    int sc=1;//so canh cua cay bao trum
    t[0]=1;  //ket nap dinh 0 vao dau tien
    while(sc<=n-1)
	{
	   chon=BestSelect();//lay dinh gan nhat trong cac dinh con lai
	   t[chon]=1;//danh dau da lay dinh da chon
	   //lay cung
	   dau[sc]=gan[chon];//dinh gan voi dinh vua duoc chon
       cuoi[sc]=chon;
	   //cap nhap lai khoang cach ngan nhat tu tung dinh con lai
	   //den tap dinh da chon
	   for(int i=0;i<=n-1;i++)
       //neu dinh i chua duoc chon, va k/c cu tu i den tap 
	   //dinh da chon > trong so cung (i,chon) thi co k/c moi
	   //va dinh gan voi dinh i la dinh 'chon' 
       if(!t[i]&&d[i]>a[i][chon])
       {
	       d[i]=a[i][chon];
	       gan[i]=chon;
       }
       sc++;
	}
}

void main()
{
	Nhap();
	KhoiTao();//khoang cach tu  dinh 0 den cac dinh con lai
	cout<<"\nMa tran trong so:\n";
	In();
	cout<<"\nCac cung cua cay bao trum ngan nhat:"<<"\n";
	Prim();
	//In ra cung bao trum ngan nhat
	for(int i=1;i<=n-1;i++)
	cout<<"  "<<dau[i]<<"---"<<cuoi[i]<<"\n";
	getch();
}
