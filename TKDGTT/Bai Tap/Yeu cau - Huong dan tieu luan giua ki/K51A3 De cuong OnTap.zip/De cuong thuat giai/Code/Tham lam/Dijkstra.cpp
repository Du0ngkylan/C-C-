#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define max 1000

int n,m;
int s,f;
int count; // so dinh thuoc duong di dap an
int c[20][20]; //ma tran trong so
int DuongDi[20];
// Cau truc cua moi dinh
typedef struct 
{
	int pre; // dinh truoc 
	int length;	 // tong do dai cung giua dinh va cac dinh khac
	int DaQua;// de danh dau dinh da qua hay chua 
}node;
node dinh[20];

void NhapDuLieu(),void Dijkstra(),void InKetQua();

void NhapDuLieu()
{
	int i,j,k;
	int temp;
	printf("\n Nhap so dinh cua do thi n=");
	scanf("%d",&n);
	printf("\n Nhap so canh cua do thi m=");
	scanf("%d",&m);

// Khoi tao cho moi dinh
	for(i=0;i<n;i++)
	{
		dinh[i].pre=-1;
		dinh[i].length=max;
		dinh[i].DaQua=0;
	}

	
//khoi tao ma tran trong so khi khong co duong di
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			c[i][j]=max;

//duong di tu 1 dinh den chinh no
	for(i=0;i<n;i++)
		c[i][i]=0;	

//nhap du lieu		  
	for(k=0;k<m;k++)
	{
		printf("\n Nhap cap canh:");
		scanf("%d%d",&i,&j);
		printf("\n Nhap do dai canh :");
		scanf("%d",&temp);
		c[i-1][j-1]=temp;
	}
// in lai ma tran trong so	
	printf("\n Ma tran trong so cua do thi da nhap la: \n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
			printf(" %d ",c[i][j]);
		printf("\n");
	}

	printf("\n Nhap dinh xuat phat:");
	scanf("%d",&s);
	printf("\n Nhap dinh can den:");   
	scanf("%d",&f);
}

void Dijkstra()
{	
	
	int i,k,min;
//Xuat phat tu dinh xuat phat
	dinh[s-1].length=0;
	dinh[s-1].DaQua=1;
	k=s-1;
	
// Tim duong di tot hon tu dinh k
	do
	{
// Cap nhap nhan length cho moi dinh
		for(i=0;i<n;i++)
		{
			if((c[k][i]!=0) && (dinh[i].DaQua==0))
			{
				if((dinh[k].length+c[k][i])<dinh[i].length)
				{
					dinh[i].pre=k; 
					dinh[i].length=dinh[k].length+c[k][i];
				}
			}
		}	

		k=0;
		min=max;
// Tim dinh chua qua va co do dai nho nhat
		for(i=0;i<n;i++)
		{
			if((dinh[i].DaQua==0) && (dinh[i].length<min))
			{
				min=dinh[i].length;
				k=i;
			}
		}
		dinh[k].DaQua=1;
	} while(k!=(f-1));


		i=0;
		k=f-1;
		count=0;
		do
		{
			DuongDi[i]=k;
			k=dinh[k].pre;
			i++;
			count++;
		} while(k!=(s-1));

		DuongDi[i]=s-1;
		count++;
		InKetQua();

}

void InKetQua()
{
	
	int i;
	printf("\n Duong di ngan nhat tu dinh %d toi dinh %d la:\n",s,f);
	for(i=count-1;i>=1;i--)	
		printf("  %d --> ",(DuongDi[i]+1));
	printf("  %d",(DuongDi[0]+1));
	printf("\n Tong chi phi cua duong di la: %d",dinh[f-1].length);
}

void main()
{           
	NhapDuLieu();
	Dijkstra();
	getch();
}