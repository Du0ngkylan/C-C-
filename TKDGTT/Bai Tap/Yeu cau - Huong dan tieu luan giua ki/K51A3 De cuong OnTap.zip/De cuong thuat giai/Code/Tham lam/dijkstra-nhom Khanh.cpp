#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include<math.h>

int const MAX=100;
int const VC=30000;
int a[100][100];
int n;

void Xuatdd(int s,int k,int *Ddnn)
{
 	 int i;
 	 cout<<"\nDuong di ngan nhat tu: "<<s<<"den "<<k<<"la: ";
 	 i=k;
 	 while(i!=s)
 	 {
			cout<<i<<"<--";
			i=Ddnn[i];
		}
		cout<<s;
		
}

void dijkstra(int s)
{
 	 int Ddnn[MAX];//chua duong di ngan nhat tu s toi dinh t tai moi buc
 	 int i,k,Dht,Min;
 	 int Daxet[MAX];//danh dau cac dinh da dua vao S
 	 int L[MAX];
 	 for(i=1;i<=n;i++)
 	 {
			Daxet[i]=0;
			L[i]=VC;
			
		}
		//dua dinh s vao tap dinh S da xet
		Daxet[s]=1;
		L[s]=0;
		Dht=s;
		int h=1;//dem moi buoc cho du n-1 buoc
		while(h<=n-1)
		{
			Min =VC;
			for(i=1;i<=n;i++)
			{
				if(!Daxet[i])
				{
					if((L[Dht]+a[Dht][i])<L[i]) //Tinh lai nhan
					{
						L[i]=L[Dht]+a[Dht][i];
						Ddnn[i]=Dht;
						//Gan dinh hien tai la dinh truoc dinh i tren lo trinh
					}
					if(L[i]<Min)//chon dinh k
					{
						Min=L[i];
						k=i;
					}
					
				}
			}
			//Tai buoc h : Tim duoc duong di ngan nhat tu h den k
			Xuatdd(s,k,Ddnn);
			cout<<"\nTrong so: "<<L[k];
			Dht=k; //Khoi dong lai diem hien tai
			Daxet[Dht]=1;  //dua nut k vao tap nut da xet
			h++;
		}
}


int main()
{
	int i,j,s;
	cout<<"Nhap so dinh cua do thi: ";
	cin>>n;
	cout<<"Nhap ma tran trong so:" ;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			//cout<<"a["<<i<<"]"<<"["<<j<<"]= ";
//			cin>>a[i][j];
			printf("a[%d][%d]",i,j);
			scanf("%d",&a[i][j]);
		}
	}
	cout<<"Cho biet dinh xuat phat:";
	cin>>s;
	dijkstra(s);
	getch();
	return 0;
}
