#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int n,m,x[3][100],kq[3][100],r=0;

void nhapfile()
{
	int i,j;
	FILE *f;
	char ten[20];
	printf("\nNhap ten file: ");
	gets(ten);
	f=fopen(ten,"r");
	if (f==NULL)
	{
		printf("\n khong mo duoc file");
		getch();
		exit(0);
	}
	fscanf(f,"%d%d",&n,&m);
	for(j=0;j<n;j++)
		fscanf(f,"%d%d%d",&x[0][j],&x[1][j],&x[2][j]);
	fclose(f);
}


void Prim()
{
	int i,j,dem = 0,min,k,h;
	int d[50];
	d[0]=1;
	for(i=1;i<m;i++)	
		d[i]=0;
	while(dem < m-1)
	{
		min=100;
		for(i=0;i<n;i++)
		{	
			if(d[x[0][i]]==1 && d[x[1][i]]==0)
			{
				if(min > x[2][i])
				{
					j=i;
					min = x[2][i];						
				}
			}
			else
			{
				if(d[x[0][i]]==0 && d[x[1][i]]==1)
					if(min > x[2][i])
					{
						j=i;
						min = x[2][i];									
					}
			}		
		}
		if(min==100)
		{
			printf("\nDo thi ko lien thong nen khong co cay bao trum nho nhat \n");
			r=1;
			exit(0);
		}
		else
		{
			d[x[0][j]]= d[x[1][j]]=1;
			kq[0][dem]= x[0][j];
			kq[1][dem]= x[1][j];
			kq[2][dem]= min;
			dem++;
		}
	}
}

void InDoThi()
{
	int i,j;
	for(j=0;j<n;j++)
	{
		printf("\n");
		for(i=0;i<3;i++)
			printf(" %d ", x[i][j]);
	}
}

void InKetQua()
{
	int i,j;
	for(j=0;j<m-1;j++)
	{
		printf("\n");
		for(i=0;i<3;i++)
			printf(" %d ", kq[i][j]);
	}
}

int main(void)
{
	nhapfile();
	printf("\nDo thi \n ");
	InDoThi();
	Prim();
	if(r==0)
	{
		printf("\n\nCay bao trum nho nhat cua do thi:\n");
		InKetQua();
	}
}
