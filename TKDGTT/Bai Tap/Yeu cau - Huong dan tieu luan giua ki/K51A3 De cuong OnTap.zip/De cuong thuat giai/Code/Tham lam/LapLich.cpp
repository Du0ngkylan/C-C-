#include<stdio.h>
#include<conio.h>
typedef struct
{
int s;
int f;
} cv;
int n;
cv viec[50];
void NhapDuLieu()
{
	 int i,t1,t2;
	 printf("\n Nhap so hoat dong can sap xep: ") ;
	 scanf("%d",&n);
	 for(i=1;i<=n;i++)
	 {
		printf("\n Start time:");scanf("%d",&t1);
		viec[i].s=t1;
		printf("\n Finish time:");scanf("%d",&t2);
		viec[i].f=t2;
	 }
}
void SapXep()
	{
		int i,j;
		cv tmp;
		for(i=1;i<=n;i++)
			for(j=i+1;j<=n;j++)
			{
				if(viec[j].f<=viec[i].f)
					{

						 tmp=viec[j];
						 viec[j]=viec[i];
						 viec[i]=tmp;
					}
			}
}
void LapLich()
{
			int k1,k2,count;
			k1=1;
			count=1;
			printf("\n Cac hoat dong duoc sap xep nhu sau:");
			printf("\nCong viec 1: %5d %5d\n",viec[1].s,viec[1].f);
			for(k2=2;k2<=n;k2++)
				{
					if(viec[k2].s>=viec[k1].f)
					{	count++;
						printf("Cong viec %d: %5d %5d\n",count,viec[k2].s,viec[k2].f) ;
						k1=k2;
					}
				}
}
void main()
{
	NhapDuLieu();
	SapXep();
	LapLich();
	getch();
}